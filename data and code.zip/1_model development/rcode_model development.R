###################################################################################
###################################################################################
## Transmission model for 2019-nCoV in Korea
## Estimating the effectiveness of non-pharmaceutical interventions on COVID-19 control in South Korea
## by Kyung-Duk Min  last updated: April 30 2020
###################################################################################
###################################################################################

######################################################################################################
######################################################################################################
## COVID 19 - Mathematical model development (South Korea)
######################################################################################################
######################################################################################################

######################################################################################################
######################################################################################################
## Two population groups; aged 19-, aged 20+
######################################################################################################
######################################################################################################
raw<-read.csv("data_040720.csv",stringsAsFactors = F)
pop<-read.csv("data_pop.csv",stringsAsFactors = F)
raw$date<-as.Date(raw$date)

raw$newcase_20<-raw$newcase_all-raw$newcase_0_9-raw$newcase_10_19 - raw$imported_blocked
raw$newcase_1_19<-raw$newcase_0_9+raw$newcase_10_19
raw$newcase_import<-raw$imported_unblocked

raw1<-raw[,c('date','newcase_1_19','newcase_20','newcase_import')]
raw<-raw1
names(raw)

# data overview  
par(mfcol=c(3,1),mar=c(3,3,2,1))
for(i in 2:4){
  plot(raw[,c(1,i)],type='b',main=names(raw)[i]) # total newcases
}

sum(raw$newcase_1_19) # 668
sum(raw$newcase_20)   # 9312

scale.factor<-matrix(c(9312/668,1),nrow=2,ncol=1)

######################################################################################################
## Paramters and model structure
######################################################################################################
num.metapop<-2
total.time<-78
start.time<-30
start.time.lag<-7
(time.duration<-total.time-(start.time-start.time.lag)) #55
(time.semester.start<-which(raw$date=='2020-03-02')-(start.time-start.time.lag)) # 20

target.outcome.new<-matrix(NA,ncol=time.duration,nrow=num.metapop)
for(i in 1:num.metapop){
  target.outcome.new[i,]<-raw[((start.time-start.time.lag)+1):total.time,i+1]
}

target.outcome.cumul<-matrix(NA,ncol=time.duration,nrow=num.metapop)
for(i in 1:num.metapop){for(j in 1:ncol(target.outcome.new)){
  target.outcome.cumul[i,j]<-sum(target.outcome.new[i,1:j])
}}


reported.imported.case<-raw[((start.time-start.time.lag)+1):total.time,4]
reported.imported.case<-c(reported.imported.case,reported.imported.case[length(reported.imported.case)])
length(reported.imported.case)

# parameters
theta<-5.5-1   # incubation period (day)
gamma <- 4.8+1 #detection time (from infectious to isolation) median value from Ki et al 2020
q.prob <-0.04  # quarantine probability of exposed individuals


# simulation matrix structure 
epidemic.mat.S<-matrix(NA,ncol=time.duration,nrow=num.metapop)
epidemic.mat.E<-matrix(NA,ncol=time.duration,nrow=num.metapop)
epidemic.mat.I<-matrix(NA,ncol=time.duration,nrow=num.metapop)
epidemic.mat.Q<-matrix(NA,ncol=time.duration,nrow=num.metapop)
epidemic.mat.H<-matrix(NA,ncol=time.duration,nrow=num.metapop)
epidemic.mat.N<-matrix(c(pop$y2020[2]+pop$y2020[3],pop$y2020[1]-pop$y2020[2]-pop$y2020[3]),ncol=1,nrow=num.metapop)

epidemic.mat.Import.I<-matrix(NA,ncol=time.duration,nrow=num.metapop)
epidemic.mat.Import.H<-matrix(NA,ncol=time.duration,nrow=num.metapop)
for(t in 1:time.duration){epidemic.mat.Import.I[,t]<-c(0,reported.imported.case[t+1]*gamma)}
for(t in 1:time.duration){epidemic.mat.Import.H[,t]<-c(0,reported.imported.case[t])}

# initial value 
epidemic.mat.S[,1]<-c(pop$y2020[2]+pop$y2020[3],pop$y2020[1]-pop$y2020[2]-pop$y2020[3])
epidemic.mat.E[,1]<-0
epidemic.mat.I[,1]<-c(0,3)
epidemic.mat.Q[,1]<-0 #round(c(264*((pop$y2020[2]+pop$y2020[3])/pop$y2020[1]),264*(1-((pop$y2020[2]+pop$y2020[3])/pop$y2020[1]))))
epidemic.mat.H[,1]<-1


split.structure.1<-c(rep(1,20),rep(2,time.duration-20))
split.structure.2<-ceiling(seq_along(1:time.duration)/7)


## initial Contact rate paramters function 

ini.c.rate.fun<-function(split.structure.1,split.structure.2,ini.beta.param.list,beta.cross.1,beta.cross.2){
  

  for(j in 1:length(varying.unit.1)){
    assign(paste0('beta.',1,'.',j), ini.beta.param.list[[1]][j] ) 
  }
  
  for(j in 1:length(varying.unit.2)){
    assign(paste0('beta.',2,'.',j), ini.beta.param.list[[2]][j] ) 
  }
  
  contact.rate.per.group<-list(NA)
  contact.rate.per.group[[1]]<-varying.unit.1
  contact.rate.per.group[[2]]<-varying.unit.2
  
  
  beta.names.1<-c(NA)
  beta.names.2<-c(NA)
  for(j in 1:length(varying.unit.1)){
    beta.names.1[j]<-paste0('beta.',1,'.',j)
    contact.rate.per.group[[1]][[j]]<- rep(get(paste0('beta.',1,'.',j)),length(contact.rate.per.group[[1]][[j]]))
  }
  for(j in 1:length(varying.unit.2)){
    beta.names.2[j]<-paste0('beta.',2,'.',j)
    contact.rate.per.group[[2]][[j]]<- rep(get(paste0('beta.',2,'.',j)),length(contact.rate.per.group[[2]][[j]]))
  }
  
  beta.names<-c(beta.names.1,beta.names.2)
  
  
  as.numeric(unlist(contact.rate.per.group[[1]]))
  as.numeric(unlist(contact.rate.per.group[[2]]))
  
  
  # contact rate matrix (list) each element in the list indicates time (Day)
  contact.rate.mat<-list(NA)
  for(j in 1:time.duration){contact.rate.mat[[j]]<-matrix(NA,nrow=2,ncol=2) }
  for(j in 1:time.duration){
    contact.rate.mat[[j]] [1,2]<- as.numeric(unlist(contact.rate.per.group[[2]])) [j] *beta.cross.2 #*beta.cross.3
    contact.rate.mat[[j]] [2,2]<- as.numeric(unlist(contact.rate.per.group[[2]])) [j]
    contact.rate.mat[[j]] [2,1]<- as.numeric(unlist(contact.rate.per.group[[1]])) [j] *beta.cross.1#*(1/beta.cross.3)
    contact.rate.mat[[j]] [1,1]<- as.numeric(unlist(contact.rate.per.group[[1]])) [j]
  }
  
  return(list(contact.rate.mat,beta.names))
}

## Functions for likelihood 

Lik.Sim.COVID19.meta.pop<-function(contact.rate.mat){
  # simulation matrix structure 
  epidemic.mat.S<-matrix(NA,ncol=time.duration,nrow=num.metapop)
  epidemic.mat.E<-matrix(NA,ncol=time.duration,nrow=num.metapop)
  epidemic.mat.I<-matrix(NA,ncol=time.duration,nrow=num.metapop)
  epidemic.mat.Q<-matrix(NA,ncol=time.duration,nrow=num.metapop)
  epidemic.mat.H<-matrix(NA,ncol=time.duration,nrow=num.metapop)
  epidemic.mat.N<-matrix(c(pop$y2020[2]+pop$y2020[3],pop$y2020[1]-pop$y2020[2]-pop$y2020[3]),ncol=1,nrow=num.metapop)
  
  epidemic.mat.Import.I<-matrix(NA,ncol=time.duration,nrow=num.metapop)
  epidemic.mat.Import.H<-matrix(NA,ncol=time.duration,nrow=num.metapop)
  for(t in 1:time.duration){epidemic.mat.Import.I[,t]<-c(0,reported.imported.case[t+1]*gamma)}
  for(t in 1:time.duration){epidemic.mat.Import.H[,t]<-c(0,reported.imported.case[t])}
  
  
  # initial value 
  epidemic.mat.S[,1]<-c(pop$y2020[2]+pop$y2020[3],pop$y2020[1]-pop$y2020[2]-pop$y2020[3])
  epidemic.mat.E[,1]<-0
  epidemic.mat.I[,1]<-c(0,3)
  epidemic.mat.Q[,1]<-0 #round(c(264*((pop$y2020[2]+pop$y2020[3])/pop$y2020[1]),264*(1-((pop$y2020[2]+pop$y2020[3])/pop$y2020[1]))))
  epidemic.mat.H[,1]<-1
  

  beta <- contact.rate.mat
  
  #likelihood 
  for(t in 1:(ncol(epidemic.mat.S)-1)){
    
    
    epidemic.mat.S [,t+1]<-epidemic.mat.S [,t]  - ((beta[[t]]%*%(epidemic.mat.I[,t]+epidemic.mat.Import.I[,t]))*(epidemic.mat.S[,t]/epidemic.mat.N))
    epidemic.mat.E [,t+1]<-epidemic.mat.E [,t]  + (1-q.prob)*((beta[[t]]%*%(epidemic.mat.I[,t]+epidemic.mat.Import.I[,t]))*(epidemic.mat.S[,t]/epidemic.mat.N))  - ((1/theta)*epidemic.mat.E[,t])
    epidemic.mat.I [,t+1]<-epidemic.mat.I [,t]  + ((1/theta)*epidemic.mat.E[,t]) - ((1/gamma)*epidemic.mat.I[,t])
    epidemic.mat.Q [,t+1]<-epidemic.mat.Q [,t]  + (q.prob)*((beta[[t]]%*%(epidemic.mat.I[,t]+epidemic.mat.Import.I[,t]))*(epidemic.mat.S[,t]/epidemic.mat.N))  - ((1/theta)*epidemic.mat.Q[,t])
    epidemic.mat.H [,t+1]<-epidemic.mat.H [,t]  + ((1/gamma)*epidemic.mat.I[,t]) + ((1/theta)*epidemic.mat.Q[,t]) +epidemic.mat.Import.H[,t+1]
    
  }
  newcase<-matrix(NA,ncol=ncol(epidemic.mat.S),nrow=num.metapop)
  newcase[,1]<-0
  for(j in 2:ncol(epidemic.mat.S)){newcase[,j]<-epidemic.mat.H[,j]-epidemic.mat.H[,j-1]}
  logLik<-matrix(NA,ncol=1,nrow=num.metapop)
  
  for(j in 1:num.metapop){
    logLik[j]<-sum(dpois(round(target.outcome.new[j,2:time.duration]*scale.factor[j]), newcase[j,2:time.duration]*scale.factor[j],log=T)) }
  
  #for(j in 1:num.metapop){
  #logLik[j]<-sum(dpois(target.outcome.cumul[j,2:time.duration], epidemic.mat.H[j,2:time.duration],log=T))}
  
  
  
  # par(mfrow=c(1,2))
  #  plot(target.outcome[1,2:39],type='b')
  #  lines(newcase[1,2:39],col=2)
  #  plot(target.outcome[2,2:39],type='b')
  #  lines(newcase[1,2:39],col=2)
  
  
  sum(logLik)
  
  return(sum(logLik))
  
}


######################################################################################################
## Calibration - MCMC
######################################################################################################

library(doParallel)
iteration <-50* 10^4
set.seed(870827);beta.ini<-round(runif(3,0.1,2),1)
beta.ini<-c(0.1,0.05,0.15)
beta.cross.ini<-c(0.6,0.75,0.8)

start.time.t<-Sys.time()
MCMC.results.multi.chain<-foreach(m = 1:3)%dopar%{

  
varying.unit.1<-split(1:time.duration,  split.structure.1)
varying.unit.2<-split(1:time.duration,  split.structure.2)


ini.beta.param.list<-list(NA)
ini.beta.param.list[[1]]<-c(beta.ini[m],beta.ini[m]/3)
ini.beta.param.list[[2]]<-rep(beta.ini[m],length(varying.unit.2))

beta.cross.1<-beta.ini[m]
beta.cross.2<-beta.ini[m]
beta.cross.3<-beta.cross.ini[m]


ini.c.rate<-ini.c.rate.fun(split.structure.1,split.structure.2,ini.beta.param.list,beta.cross.1,beta.cross.2)
contact.rate.mat<-ini.c.rate[[1]]
beta.names<-ini.c.rate[[2]]
beta.names.new<-c(beta.names,'beta.cross.1','beta.cross.2')

beta.names.new.1<-beta.names.new[c(1,2)]
beta.names.new.2<-beta.names.new[-c(1,2)]

param.mat<-matrix(NA,ncol=length(beta.names)+2+4, 
                  nrow=iteration)
colnames(param.mat)<-c(beta.names,"beta.cross.1","beta.cross.2",
                       "logLik","logLik.ratio","random.n","accept")
for(j in 1:length(ini.beta.param.list[[1]]) ){param.mat[1,j]<-ini.beta.param.list[[1]][j] }
for(j in 1:length(ini.beta.param.list[[2]]) ){param.mat[1,(j+length(ini.beta.param.list[[1]])) ]<-ini.beta.param.list[[2]][j] }

param.mat[1,"beta.cross.1"]<-beta.cross.1
param.mat[1,"beta.cross.2"]<-beta.cross.2

param.mat[1,"logLik"]<-Lik.Sim.COVID19.meta.pop(contact.rate.mat)
param.mat[1,"logLik.ratio"]<-1
param.mat[1,"random.n"]<-runif(1,0,1)
param.mat[1,"accept"]<-1


for(i in 2:iteration){
  param.mat.temp<-param.mat[which(param.mat[ ,"accept"]==1),]
  if(class(param.mat.temp)=="numeric"){
    param.mat.temp<-param.mat.temp
  }else{
    param.mat.temp<-param.mat.temp[nrow(param.mat.temp),]
  }
  
  
  temp<-i%%length(beta.names.new)
  if(temp==0){  temp2<-length(beta.names.new)  }else{temp2<-temp}
  
  if (beta.names.new[temp2]%in%c('beta.2.1')){range <- 0.5 
  }else if(beta.names.new[temp2]%in%c('beta.cross.1')){range<-0.1
  }else{range<-0.01}
  param.mat[i,beta.names.new[temp2]]<-runif(1,min= max(param.mat.temp[beta.names.new[temp2]]-range,0) ,max=param.mat.temp[beta.names.new[temp2]]+range )
  param.mat[i,beta.names.new[-temp2]]<-param.mat.temp[beta.names.new[-temp2]]
  
  
  # contact rate matrix (list) each element in the list indicates time (Day)    
  
  param.list<-ini.beta.param.list
  for(j in 1:length(varying.unit.1)){param.list[[1]][j]<-param.mat[i,paste0("beta.1.",j)]  }
  for(j in 1:length(varying.unit.2)){param.list[[2]][j]<-param.mat[i,paste0("beta.2.",j)]}
  
  
  c.rate<-ini.c.rate.fun(split.structure.1,split.structure.2, param.list,param.mat[i,"beta.cross.1"],param.mat[i,"beta.cross.2"])
  
  contact.rate.mat<-c.rate[[1]]
  
  
  
  param.mat[i,"logLik"]<-Lik.Sim.COVID19.meta.pop(contact.rate.mat)
  
  if (sum( param.mat[i,beta.names]<0 )+ ( param.mat[i,'beta.cross.1']<0 )+( param.mat[i,'beta.cross.2']<0 )+#( param.mat[i,'beta.cross.3']<0.1 ) 
      (param.mat[i,'beta.cross.1']>=1 )+( param.mat[i,'beta.cross.2']>=1 ) ==0 ){
  param.mat[i,"logLik.ratio"]<-exp(param.mat[i,"logLik"]-param.mat.temp["logLik"])}else{
  param.mat[i,"logLik.ratio"]<-0
  }
  
  
  param.mat[i,"random.n"]<-runif(1,0,1)
  
  if( (min( param.mat[i,"logLik.ratio"] ,1) >= param.mat[i,"random.n"]) ){param.mat[i,"accept"]<-1 }else{param.mat[i,"accept"]<-0 }

}
  return(param.mat)
 
}
end.time.t<-Sys.time()
end.time.t-start.time.t  

param.mat.1<-MCMC.results.multi.chain[[1]]
param.mat.2<-MCMC.results.multi.chain[[2]]
param.mat.3<-MCMC.results.multi.chain[[3]]


prop.table(table(param.mat.1[,"accept"]))*100
prop.table(table(param.mat.2[,"accept"]))*100
prop.table(table(param.mat.3[,"accept"]))*100

param.mat.final.1<-subset(param.mat.1,param.mat.1[,"accept"]==1)
param.mat.final.2<-subset(param.mat.2,param.mat.2[,"accept"]==1)
param.mat.final.3<-subset(param.mat.3,param.mat.3[,"accept"]==1)

#write.csv(param.mat.final.1,'results_041820/chain_1.csv')
#write.csv(param.mat.final.2,'results_041820/chain_2.csv')
#write.csv(param.mat.final.3,'results_041820/chain_3.csv')

round(param.mat.final.1[nrow(param.mat.final.1),],5)
round(param.mat.final.2[nrow(param.mat.final.2),],5)
round(param.mat.final.3[nrow(param.mat.final.3),],5)


#trajectory plots
nrow(param.mat.final)

beta.names.new<-c(beta.names,'beta.cross.1','beta.cross.2')
burn.in=100000
end=200000
par(mfrow=c(3,1),mar=c(4,4,1.2,1.2) )

plot(param.mat.final.1[(burn.in+1):end,'beta.1.1' ], type='l',ylab="",xlab="",las=1,col=1,main='')
lines(param.mat.final.2[(burn.in+1):end,'beta.1.1'], type='l',ylab="",xlab="",las=1,col=2)
lines(param.mat.final.3[(burn.in+1):end,'beta.1.1'], type='l',ylab="",xlab="",las=1,col=3)

plot(param.mat.final.1[(burn.in+1):end,'beta.1.2' ], type='l',ylab="",xlab="",las=1,col=1,main='')
lines(param.mat.final.2[(burn.in+1):end,'beta.1.2'], type='l',ylab="",xlab="",las=1,col=2)
lines(param.mat.final.3[(burn.in+1):end,'beta.1.2'], type='l',ylab="",xlab="",las=1,col=3)

plot(param.mat.final.1[(burn.in+1):end,'beta.2.1' ], type='l',ylab="",xlab="",las=1,col=1,main='')
lines(param.mat.final.2[(burn.in+1):end,'beta.2.1'], type='l',ylab="",xlab="",las=1,col=2)
lines(param.mat.final.3[(burn.in+1):end,'beta.2.1'], type='l',ylab="",xlab="",las=1,col=3)

plot(param.mat.final.1[(burn.in+1):end,'beta.2.2' ], type='l',ylab="",xlab="",las=1,col=1,main='')
lines(param.mat.final.2[(burn.in+1):end,'beta.2.2'], type='l',ylab="",xlab="",las=1,col=2)
lines(param.mat.final.3[(burn.in+1):end,'beta.2.2'], type='l',ylab="",xlab="",las=1,col=3)

plot(param.mat.final.1[(burn.in+1):end,'beta.2.3' ], type='l',ylab="",xlab="",las=1,col=1,main='')
lines(param.mat.final.2[(burn.in+1):end,'beta.2.3'], type='l',ylab="",xlab="",las=1,col=2)
lines(param.mat.final.3[(burn.in+1):end,'beta.2.3'], type='l',ylab="",xlab="",las=1,col=3)

plot(param.mat.final.1[(burn.in+1):end,'beta.2.4' ], type='l',ylab="",xlab="",las=1,col=1,main='')
lines(param.mat.final.2[(burn.in+1):end,'beta.2.4'], type='l',ylab="",xlab="",las=1,col=2)
lines(param.mat.final.3[(burn.in+1):end,'beta.2.4'], type='l',ylab="",xlab="",las=1,col=3)

plot(param.mat.final.1[(burn.in+1):end,'beta.2.5' ], type='l',ylab="",xlab="",las=1,col=1,main='')
lines(param.mat.final.2[(burn.in+1):end,'beta.2.5'], type='l',ylab="",xlab="",las=1,col=2)
lines(param.mat.final.3[(burn.in+1):end,'beta.2.5'], type='l',ylab="",xlab="",las=1,col=3)

plot(param.mat.final.1[(burn.in+1):end,'beta.2.6' ], type='l',ylab="",xlab="",las=1,col=1,main='')
lines(param.mat.final.2[(burn.in+1):end,'beta.2.6'], type='l',ylab="",xlab="",las=1,col=2)
lines(param.mat.final.3[(burn.in+1):end,'beta.2.6'], type='l',ylab="",xlab="",las=1,col=3)

plot(param.mat.final.1[(burn.in+1):end,'beta.2.7' ], type='l',ylab="",xlab="",las=1,col=1,main='')
lines(param.mat.final.2[(burn.in+1):end,'beta.2.7'], type='l',ylab="",xlab="",las=1,col=2)
lines(param.mat.final.3[(burn.in+1):end,'beta.2.7'], type='l',ylab="",xlab="",las=1,col=3)

plot(param.mat.final.1[(burn.in+1):end,'beta.2.8' ], type='l',ylab="",xlab="",las=1,col=1)
lines(param.mat.final.2[(burn.in+1):end,'beta.2.8'], type='l',ylab="",xlab="",las=1,col=2)
lines(param.mat.final.3[(burn.in+1):end,'beta.2.8'], type='l',ylab="",xlab="",las=1,col=3)

plot(param.mat.final.1[(burn.in+1):end,'beta.cross.1' ], type='l',ylab="",xlab="",las=1,col=1,main='')
lines(param.mat.final.2[(burn.in+1):end,'beta.cross.1'], type='l',ylab="",xlab="",las=1,col=2)
lines(param.mat.final.3[(burn.in+1):end,'beta.cross.1'], type='l',ylab="",xlab="",las=1,col=3)

plot(param.mat.final.1[(burn.in+1):end,'beta.cross.2' ], type='l',ylab="",xlab="",las=1,col=1,main='')
lines(param.mat.final.2[(burn.in+1):end,'beta.cross.2'], type='l',ylab="",xlab="",las=1,col=2)
lines(param.mat.final.3[(burn.in+1):end,'beta.cross.2'], type='l',ylab="",xlab="",las=1,col=3)



#histogram

par(mfrow=c(3,4))

hist(param.mat.final.1[burn.in:end,"beta.1.1"],main='',ylab='',col='lightblue',xlab='')
hist(param.mat.final.1[burn.in:end,"beta.1.2"],main='',ylab='',col='lightblue',xlab='')
hist(param.mat.final.1[burn.in:end,"beta.2.1"],main='',ylab='',col='lightblue',xlab='')
hist(param.mat.final.1[burn.in:end,"beta.2.2"],main='',ylab='',col='lightblue',xlab='')
hist(param.mat.final.1[burn.in:end,"beta.2.3"],main='',ylab='',col='lightblue',xlab='')
hist(param.mat.final.1[burn.in:end,"beta.2.4"],main='',ylab='',col='lightblue',xlab='')
hist(param.mat.final.1[burn.in:end,"beta.2.5"],main='',ylab='',col='lightblue',xlab='')
hist(param.mat.final.1[burn.in:end,"beta.2.6"],main='',ylab='',col='lightblue',xlab='')
hist(param.mat.final.1[burn.in:end,"beta.2.7"],main='',ylab='',col='lightblue',xlab='')
hist(param.mat.final.1[burn.in:end,"beta.cross.1"],main='',ylab='',col='lightblue',xlab='')
hist(param.mat.final.1[burn.in:end,"beta.cross.2"],main='',ylab='',col='lightblue',xlab='')




### Gelman-rubin test ################################################
G.R.test.results<-matrix(NA,nrow=length(beta.names.new),ncol=2)
colnames(G.R.test.results)<-c('beta_name','R')
G.R.test.results<-as.data.frame(G.R.test.results)
G.R.test.results[,1]<-beta.names.new

for(i in 1:length(beta.names.new)){
burn.in=100000
end=200000
mean.chain.1<-mean(param.mat.final.1[burn.in:end,beta.names.new[i] ])
mean.chain.2<-mean(param.mat.final.2[burn.in:end,beta.names.new[i] ])
mean.chain.3<-mean(param.mat.final.3[burn.in:end,beta.names.new[i] ])

intra.chain.var.1<-sum((param.mat.final.1[burn.in:end,beta.names.new[i] ]-mean.chain.1)^2)/end
intra.chain.var.2<-sum((param.mat.final.2[burn.in:end,beta.names.new[i] ]-mean.chain.2)^2)/end
intra.chain.var.3<-sum((param.mat.final.3[burn.in:end,beta.names.new[i] ]-mean.chain.3)^2)/end

mean.all.chain<-mean(c(param.mat.final.1[burn.in:end,beta.names.new[i] ],
                       param.mat.final.2[burn.in:end,beta.names.new[i] ],
                       param.mat.final.3[burn.in:end,beta.names.new[i] ]))

N <- end*3
B <- (N/(3-1))* sum((c(mean.chain.1,mean.chain.2,mean.chain.3)-mean.all.chain)^2)

W <- (1/3)*(intra.chain.var.1+intra.chain.var.2+intra.chain.var.3)

v.hat<- (((N-1)/N)*W) + (((3+1)/(3*N))*B)

R<-sqrt(v.hat/W)
G.R.test.results[i,2]<-R
}

G.R.test.results

### Parameter summary ################################################

library(HDInterval)
parameters.final<-matrix(NA, ncol=length(beta.names.new),nrow=4)
colnames(parameters.final)<-beta.names.new
rownames(parameters.final)<-c("mean","median","LL","UL")

for(i in 1:ncol(parameters.final)){
  parameters.final[1,i]<- round(mean(param.mat.final.1[burn.in:end,colnames(parameters.final)[i]  ]),4)
  parameters.final[2,i]<-round(median(param.mat.final.1[burn.in:end,colnames(parameters.final)[i]  ]),4)
  parameters.final[3,i]<-round(hdi(param.mat.final.1[burn.in:end,colnames(parameters.final)[i]  ],0.95),4)[1]
  parameters.final[4,i]<-round(hdi(param.mat.final.1[burn.in:end,colnames(parameters.final)[i]  ],0.95),4)[2]
}

round(parameters.final,2)

#write.csv(parameters.final,'results_041820/parameters_final.csv')
