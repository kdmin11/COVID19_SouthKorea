###################################################################################
###################################################################################
## Transmission model for 2019-nCoV in Korea
## Estimating the effectiveness of non-pharmaceutical interventions on COVID-19 control in South Korea
## by Kyung-Duk Min  last updated: April 30 2020
###################################################################################
###################################################################################

######################################################################################################
## Data import (parameter estimated from MCMC) and functions
######################################################################################################
param.mat.final.1<-read.csv("chain_1.csv",stringsAsFactors = F)[,-1]
param.mat.final.2<-read.csv("chain_2.csv",stringsAsFactors = F)[,-1]
param.mat.final.3<-read.csv("chain_3.csv",stringsAsFactors = F)[,-1]
parameters.final<-read.csv("parameters_final.csv",stringsAsFactors = F)[,-1]


raw<-read.csv("data_040720.csv",stringsAsFactors = F)
pop<-read.csv("data_pop.csv",stringsAsFactors = F)
raw$date<-as.Date(raw$date)

raw$newcase_20<-raw$newcase_all-raw$newcase_0_9-raw$newcase_10_19 - raw$imported_blocked
raw$newcase_1_19<-raw$newcase_0_9+raw$newcase_10_19
raw$newcase_import<-raw$imported_unblocked

raw1<-raw[,c('date','newcase_1_19','newcase_20','newcase_import')]
raw<-raw1
names(raw)

# data overview  
par(mfcol=c(3,1),mar=c(3,3,2,1))
for(i in 2:4){
  plot(raw[,c(1,i)],type='b',main=names(raw)[i]) # total newcases
}

sum(raw$newcase_1_19) # 668
sum(raw$newcase_20)   # 9312

scale.factor<-matrix(c(9312/668,1),nrow=2,ncol=1)


burn.in=100000
end=200000

ini.beta.param.list<-list(NA)
ini.beta.param.list[[1]]<-rep(1,2)
ini.beta.param.list[[2]]<-rep(1,8)


######################################################################################################
## Paramters and model structure
######################################################################################################
num.metapop<-2
total.time<-78
start.time<-30
start.time.lag<-7
(time.duration<-total.time-(start.time-start.time.lag)) #55
(time.semester.start<-which(raw$date=='2020-03-02')-(start.time-start.time.lag)) # 20

target.outcome.new<-matrix(NA,ncol=time.duration,nrow=num.metapop)
for(i in 1:num.metapop){
  target.outcome.new[i,]<-raw[((start.time-start.time.lag)+1):total.time,i+1]
}

target.outcome.cumul<-matrix(NA,ncol=time.duration,nrow=num.metapop)
for(i in 1:num.metapop){for(j in 1:ncol(target.outcome.new)){
  target.outcome.cumul[i,j]<-sum(target.outcome.new[i,1:j])
}}


reported.imported.case<-raw[((start.time-start.time.lag)+1):total.time,4]
reported.imported.case<-c(reported.imported.case,reported.imported.case[length(reported.imported.case)])
length(reported.imported.case)

# parameters
theta<-5.5-1   # incubation period (day)
gamma <- 4.8+1 #detection time (from infectious to isolation) median value from Ki et al 2020
q.prob <-0.04  # quarantine probability of exposed individuals


# simulation matrix structure 
epidemic.mat.S<-matrix(NA,ncol=time.duration,nrow=num.metapop)
epidemic.mat.E<-matrix(NA,ncol=time.duration,nrow=num.metapop)
epidemic.mat.I<-matrix(NA,ncol=time.duration,nrow=num.metapop)
epidemic.mat.Q<-matrix(NA,ncol=time.duration,nrow=num.metapop)
epidemic.mat.H<-matrix(NA,ncol=time.duration,nrow=num.metapop)
epidemic.mat.N<-matrix(c(pop$y2020[2]+pop$y2020[3],pop$y2020[1]-pop$y2020[2]-pop$y2020[3]),ncol=1,nrow=num.metapop)

epidemic.mat.Import.I<-matrix(NA,ncol=time.duration,nrow=num.metapop)
epidemic.mat.Import.H<-matrix(NA,ncol=time.duration,nrow=num.metapop)
for(t in 1:time.duration){epidemic.mat.Import.I[,t]<-c(0,reported.imported.case[t+1]*gamma)}
for(t in 1:time.duration){epidemic.mat.Import.H[,t]<-c(0,reported.imported.case[t])}

# initial value 
epidemic.mat.S[,1]<-c(pop$y2020[2]+pop$y2020[3],pop$y2020[1]-pop$y2020[2]-pop$y2020[3])
epidemic.mat.E[,1]<-0
epidemic.mat.I[,1]<-c(0,3)
epidemic.mat.Q[,1]<-0 #round(c(264*((pop$y2020[2]+pop$y2020[3])/pop$y2020[1]),264*(1-((pop$y2020[2]+pop$y2020[3])/pop$y2020[1]))))
epidemic.mat.H[,1]<-1


split.structure.1<-c(rep(1,20),rep(2,time.duration-20))
split.structure.2<-ceiling(seq_along(1:time.duration)/7)


varying.unit.1<-split(1:time.duration,  split.structure.1)
varying.unit.2<-split(1:time.duration,  split.structure.2)


## initial Contact rate paramters function 

ini.c.rate.fun<-function(split.structure.1,split.structure.2,ini.beta.param.list,beta.cross.1,beta.cross.2){
  
  
  for(j in 1:length(varying.unit.1)){
    assign(paste0('beta.',1,'.',j), ini.beta.param.list[[1]][j] ) 
  }
  
  for(j in 1:length(varying.unit.2)){
    assign(paste0('beta.',2,'.',j), ini.beta.param.list[[2]][j] ) 
  }
  
  contact.rate.per.group<-list(NA)
  contact.rate.per.group[[1]]<-varying.unit.1
  contact.rate.per.group[[2]]<-varying.unit.2
  
  
  beta.names.1<-c(NA)
  beta.names.2<-c(NA)
  for(j in 1:length(varying.unit.1)){
    beta.names.1[j]<-paste0('beta.',1,'.',j)
    contact.rate.per.group[[1]][[j]]<- rep(get(paste0('beta.',1,'.',j)),length(contact.rate.per.group[[1]][[j]]))
  }
  for(j in 1:length(varying.unit.2)){
    beta.names.2[j]<-paste0('beta.',2,'.',j)
    contact.rate.per.group[[2]][[j]]<- rep(get(paste0('beta.',2,'.',j)),length(contact.rate.per.group[[2]][[j]]))
  }
  
  beta.names<-c(beta.names.1,beta.names.2)
  
  
  as.numeric(unlist(contact.rate.per.group[[1]]))
  as.numeric(unlist(contact.rate.per.group[[2]]))
  
  
  # contact rate matrix (list) each element in the list indicates time (Day)
  contact.rate.mat<-list(NA)
  for(j in 1:time.duration){contact.rate.mat[[j]]<-matrix(NA,nrow=2,ncol=2) }
  for(j in 1:time.duration){
    contact.rate.mat[[j]] [1,2]<- as.numeric(unlist(contact.rate.per.group[[2]])) [j] *beta.cross.2 #*beta.cross.3
    contact.rate.mat[[j]] [2,2]<- as.numeric(unlist(contact.rate.per.group[[2]])) [j]
    contact.rate.mat[[j]] [2,1]<- as.numeric(unlist(contact.rate.per.group[[1]])) [j] *beta.cross.1#*(1/beta.cross.3)
    contact.rate.mat[[j]] [1,1]<- as.numeric(unlist(contact.rate.per.group[[1]])) [j]
  }
  
  return(list(contact.rate.mat,beta.names))
}

## Functions for likelihood 

Lik.Sim.COVID19.meta.pop<-function(contact.rate.mat){
  # simulation matrix structure 
  epidemic.mat.S<-matrix(NA,ncol=time.duration,nrow=num.metapop)
  epidemic.mat.E<-matrix(NA,ncol=time.duration,nrow=num.metapop)
  epidemic.mat.I<-matrix(NA,ncol=time.duration,nrow=num.metapop)
  epidemic.mat.Q<-matrix(NA,ncol=time.duration,nrow=num.metapop)
  epidemic.mat.H<-matrix(NA,ncol=time.duration,nrow=num.metapop)
  epidemic.mat.N<-matrix(c(pop$y2020[2]+pop$y2020[3],pop$y2020[1]-pop$y2020[2]-pop$y2020[3]),ncol=1,nrow=num.metapop)
  
  epidemic.mat.Import.I<-matrix(NA,ncol=time.duration,nrow=num.metapop)
  epidemic.mat.Import.H<-matrix(NA,ncol=time.duration,nrow=num.metapop)
  for(t in 1:time.duration){epidemic.mat.Import.I[,t]<-c(0,reported.imported.case[t+1]*gamma)}
  for(t in 1:time.duration){epidemic.mat.Import.H[,t]<-c(0,reported.imported.case[t])}
  
  
  # initial value 
  epidemic.mat.S[,1]<-c(pop$y2020[2]+pop$y2020[3],pop$y2020[1]-pop$y2020[2]-pop$y2020[3])
  epidemic.mat.E[,1]<-0
  epidemic.mat.I[,1]<-c(0,3)
  epidemic.mat.Q[,1]<-0 #round(c(264*((pop$y2020[2]+pop$y2020[3])/pop$y2020[1]),264*(1-((pop$y2020[2]+pop$y2020[3])/pop$y2020[1]))))
  epidemic.mat.H[,1]<-1
  
  
  beta <- contact.rate.mat
  
  #likelihood 
  for(t in 1:(ncol(epidemic.mat.S)-1)){
    
    
    epidemic.mat.S [,t+1]<-epidemic.mat.S [,t]  - ((beta[[t]]%*%(epidemic.mat.I[,t]+epidemic.mat.Import.I[,t]))*(epidemic.mat.S[,t]/epidemic.mat.N))
    epidemic.mat.E [,t+1]<-epidemic.mat.E [,t]  + (1-q.prob)*((beta[[t]]%*%(epidemic.mat.I[,t]+epidemic.mat.Import.I[,t]))*(epidemic.mat.S[,t]/epidemic.mat.N))  - ((1/theta)*epidemic.mat.E[,t])
    epidemic.mat.I [,t+1]<-epidemic.mat.I [,t]  + ((1/theta)*epidemic.mat.E[,t]) - ((1/gamma)*epidemic.mat.I[,t])
    epidemic.mat.Q [,t+1]<-epidemic.mat.Q [,t]  + (q.prob)*((beta[[t]]%*%(epidemic.mat.I[,t]+epidemic.mat.Import.I[,t]))*(epidemic.mat.S[,t]/epidemic.mat.N))  - ((1/theta)*epidemic.mat.Q[,t])
    epidemic.mat.H [,t+1]<-epidemic.mat.H [,t]  + ((1/gamma)*epidemic.mat.I[,t]) + ((1/theta)*epidemic.mat.Q[,t]) +epidemic.mat.Import.H[,t+1]
    
  }
  newcase<-matrix(NA,ncol=ncol(epidemic.mat.S),nrow=num.metapop)
  newcase[,1]<-0
  for(j in 2:ncol(epidemic.mat.S)){newcase[,j]<-epidemic.mat.H[,j]-epidemic.mat.H[,j-1]}
  logLik<-matrix(NA,ncol=1,nrow=num.metapop)
  
  for(j in 1:num.metapop){
    logLik[j]<-sum(dpois(round(target.outcome.new[j,2:time.duration]*scale.factor[j]), newcase[j,2:time.duration]*scale.factor[j],log=T)) }
  
  #for(j in 1:num.metapop){
  #logLik[j]<-sum(dpois(target.outcome.cumul[j,2:time.duration], epidemic.mat.H[j,2:time.duration],log=T))}
  
  
  
  # par(mfrow=c(1,2))
  #  plot(target.outcome[1,2:39],type='b')
  #  lines(newcase[1,2:39],col=2)
  #  plot(target.outcome[2,2:39],type='b')
  #  lines(newcase[1,2:39],col=2)
  
  
  sum(logLik)
  
  return(sum(logLik))
  
}


######################################################################################################
## Scenario analysis 
######################################################################################################

# scenario 1 (increading adult contact rate) (severe case scenario) #######################################################################################
param.mat.final.1<-parameters.final[2,]
baseline.mean<-param.mat.final.1['beta.2.6']
baseline.min<-parameters.final[3,]['beta.2.6']
baseline.max<-parameters.final[4,]['beta.2.6']
multiplier<-2 # input 1 in mild case scenario 


param.mat.final.1<-parameters.final[2,]
param.mat.final.2<-param.mat.final.1
param.mat.final.2['beta.2.3']<-baseline.mean*multiplier
param.mat.final.2['beta.2.4']<-baseline.mean*multiplier
param.mat.final.2['beta.2.5']<-baseline.mean*multiplier
param.mat.final.2['beta.2.6']<-baseline.mean*multiplier
param.mat.final.2['beta.2.7']<-baseline.mean*multiplier
param.mat.final.2['beta.2.8']<-baseline.mean*multiplier

param.mat.final.3<-param.mat.final.1
param.mat.final.3['beta.2.3']<-baseline.min*multiplier
param.mat.final.3['beta.2.4']<-baseline.min*multiplier
param.mat.final.3['beta.2.5']<-baseline.min*multiplier
param.mat.final.3['beta.2.6']<-baseline.min*multiplier
param.mat.final.3['beta.2.7']<-baseline.min*multiplier
param.mat.final.3['beta.2.8']<-baseline.min*multiplier


param.mat.final.4<-param.mat.final.1
param.mat.final.4['beta.2.3']<-baseline.max*multiplier
param.mat.final.4['beta.2.4']<-baseline.max*multiplier
param.mat.final.4['beta.2.5']<-baseline.max*multiplier
param.mat.final.4['beta.2.6']<-baseline.max*multiplier
param.mat.final.4['beta.2.7']<-baseline.max*multiplier
param.mat.final.4['beta.2.8']<-baseline.max*multiplier





param.list<-ini.beta.param.list
for(j in 1:2){param.list[[1]][j]<-param.mat.final.1[paste0("beta.1.",j)]  }
for(j in 1:8){param.list[[2]][j]<-param.mat.final.1[paste0("beta.2.",j)]  }
c.rate<-ini.c.rate.fun(split.structure.1,split.structure.2, param.list,as.numeric(param.mat.final.1["beta.cross.1"]),as.numeric(param.mat.final.1["beta.cross.2"]))
contact.rate.mat<-c.rate[[1]]
contact.rate.per.group.1<-list(NA)
contact.rate.per.group.1[[1]]<-rep(1,time.duration)
contact.rate.per.group.1[[2]]<-rep(1,time.duration)
for(i in 1:time.duration){
  contact.rate.per.group.1[[1]][i]<-contact.rate.mat[[i]][1,1]
  contact.rate.per.group.1[[2]][i]<-contact.rate.mat[[i]][2,2]
}
beta.1<-contact.rate.mat

param.list<-ini.beta.param.list
for(j in 1:2){param.list[[1]][j]<-param.mat.final.2[paste0("beta.1.",j)]  }
for(j in 1:8){param.list[[2]][j]<-param.mat.final.2[paste0("beta.2.",j)]}
c.rate<-ini.c.rate.fun(split.structure.1,split.structure.2, param.list,as.numeric(param.mat.final.2["beta.cross.1"]),as.numeric(param.mat.final.2["beta.cross.2"]))
contact.rate.mat<-c.rate[[1]]
contact.rate.per.group.2<-list(NA)
contact.rate.per.group.2[[1]]<-rep(1,time.duration)
contact.rate.per.group.2[[2]]<-rep(1,time.duration)
for(i in 1:time.duration){
  contact.rate.per.group.2[[1]][i]<-contact.rate.mat[[i]][1,1]
  contact.rate.per.group.2[[2]][i]<-contact.rate.mat[[i]][2,2]
}
beta.2<-contact.rate.mat

param.list<-ini.beta.param.list
for(j in 1:2){param.list[[1]][j]<-param.mat.final.3[paste0("beta.1.",j)]  }
for(j in 1:8){param.list[[2]][j]<-param.mat.final.3[paste0("beta.2.",j)]}
c.rate<-ini.c.rate.fun(split.structure.1,split.structure.2, param.list,as.numeric(param.mat.final.3["beta.cross.1"]),as.numeric(param.mat.final.3["beta.cross.2"]))
contact.rate.mat<-c.rate[[1]]
contact.rate.per.group.3<-list(NA)
contact.rate.per.group.3[[1]]<-rep(1,time.duration)
contact.rate.per.group.3[[2]]<-rep(1,time.duration)
for(i in 1:time.duration){
  contact.rate.per.group.3[[1]][i]<-contact.rate.mat[[i]][1,1]
  contact.rate.per.group.3[[2]][i]<-contact.rate.mat[[i]][2,2]
}
beta.3<-contact.rate.mat

param.list<-ini.beta.param.list
for(j in 1:2){param.list[[1]][j]<-param.mat.final.4[paste0("beta.1.",j)]  }
for(j in 1:8){param.list[[2]][j]<-param.mat.final.4[paste0("beta.2.",j)]}
c.rate<-ini.c.rate.fun(split.structure.1,split.structure.2, param.list,as.numeric(param.mat.final.4["beta.cross.1"]),as.numeric(param.mat.final.4["beta.cross.2"]))
contact.rate.mat<-c.rate[[1]]
contact.rate.per.group.4<-list(NA)
contact.rate.per.group.4[[1]]<-rep(1,time.duration)
contact.rate.per.group.4[[2]]<-rep(1,time.duration)
for(i in 1:time.duration){
  contact.rate.per.group.4[[1]][i]<-contact.rate.mat[[i]][1,1]
  contact.rate.per.group.4[[2]][i]<-contact.rate.mat[[i]][2,2]
}
beta.4<-contact.rate.mat



# parameters
theta<- 5.5-1   # incubation period (day)
gamma <- 4.8+1 #detection time (from infectious to isolation) median value from Ki et al 2020
q.prob <-0.04  # quarantine probability of exposed individuals


# simulation matrix structure 
epidemic.mat.S<-matrix(NA,ncol=time.duration,nrow=num.metapop)
epidemic.mat.E<-matrix(NA,ncol=time.duration,nrow=num.metapop)
epidemic.mat.I<-matrix(NA,ncol=time.duration,nrow=num.metapop)
epidemic.mat.Q<-matrix(NA,ncol=time.duration,nrow=num.metapop)
epidemic.mat.H<-matrix(NA,ncol=time.duration,nrow=num.metapop)
epidemic.mat.N<-matrix(c(pop$y2020[2]+pop$y2020[3],pop$y2020[1]-pop$y2020[2]-pop$y2020[3]),ncol=1,nrow=num.metapop)

epidemic.mat.Import.I<-matrix(NA,ncol=time.duration,nrow=num.metapop)
for(t in 1:time.duration){epidemic.mat.Import.I[,t]<-c(0,reported.imported.case[t+1]*gamma)}


# initial value 
epidemic.mat.S[,1]<-c(pop$y2020[2]+pop$y2020[3],pop$y2020[1]-pop$y2020[2]-pop$y2020[3])
epidemic.mat.E[,1]<-0
epidemic.mat.I[,1]<-c(0,3)
epidemic.mat.Q[,1]<-0 #round(c(264*((pop$y2020[2]+pop$y2020[3])/pop$y2020[1]),264*(1-((pop$y2020[2]+pop$y2020[3])/pop$y2020[1]))))
epidemic.mat.H[,1]<-1



for(t in 1:(ncol(epidemic.mat.S)-1)){
  epidemic.mat.S [,t+1]<-epidemic.mat.S [,t]  - ((beta.1[[t]]%*%(epidemic.mat.I[,t]+epidemic.mat.Import.I[,t]))*(epidemic.mat.S[,t]/epidemic.mat.N))
  epidemic.mat.E [,t+1]<-epidemic.mat.E [,t]  + (1-q.prob)*((beta.1[[t]]%*%(epidemic.mat.I[,t]+epidemic.mat.Import.I[,t]))*(epidemic.mat.S[,t]/epidemic.mat.N))  - ((1/theta)*epidemic.mat.E[,t])
  epidemic.mat.I [,t+1]<-epidemic.mat.I [,t]  + ((1/theta)*epidemic.mat.E[,t]) - ((1/gamma)*epidemic.mat.I[,t])
  epidemic.mat.Q [,t+1]<-epidemic.mat.Q [,t]  + (q.prob)*((beta.1[[t]]%*%(epidemic.mat.I[,t]+epidemic.mat.Import.I[,t]))*(epidemic.mat.S[,t]/epidemic.mat.N))  - ((1/theta)*epidemic.mat.Q[,t])
  epidemic.mat.H [,t+1]<-epidemic.mat.H [,t]  + ((1/gamma)*epidemic.mat.I[,t]) + ((1/theta)*epidemic.mat.Q[,t])
}
newcase.1<-matrix(NA,ncol=ncol(epidemic.mat.S),nrow=num.metapop)
newcase.1[,1]<-0
for(j in 2:ncol(epidemic.mat.S)){newcase.1[,j]<-epidemic.mat.H[,j]-epidemic.mat.H[,j-1]}
epidemic.mat.H.1<-epidemic.mat.H


for(t in 1:(ncol(epidemic.mat.S)-1)){
  epidemic.mat.S [,t+1]<-epidemic.mat.S [,t]  - ((beta.2[[t]]%*%(epidemic.mat.I[,t]+epidemic.mat.Import.I[,t]))*(epidemic.mat.S[,t]/epidemic.mat.N))
  epidemic.mat.E [,t+1]<-epidemic.mat.E [,t]  + (1-q.prob)*((beta.2[[t]]%*%(epidemic.mat.I[,t]+epidemic.mat.Import.I[,t]))*(epidemic.mat.S[,t]/epidemic.mat.N))  - ((1/theta)*epidemic.mat.E[,t])
  epidemic.mat.I [,t+1]<-epidemic.mat.I [,t]  + ((1/theta)*epidemic.mat.E[,t]) - ((1/gamma)*epidemic.mat.I[,t])
  epidemic.mat.Q [,t+1]<-epidemic.mat.Q [,t]  + (q.prob)*((beta.2[[t]]%*%(epidemic.mat.I[,t]+epidemic.mat.Import.I[,t]))*(epidemic.mat.S[,t]/epidemic.mat.N))  - ((1/theta)*epidemic.mat.Q[,t])
  epidemic.mat.H [,t+1]<-epidemic.mat.H [,t]  + ((1/gamma)*epidemic.mat.I[,t]) + ((1/theta)*epidemic.mat.Q[,t])
}
newcase.2<-matrix(NA,ncol=ncol(epidemic.mat.S),nrow=num.metapop)
newcase.2[,1]<-0
for(j in 2:ncol(epidemic.mat.S)){newcase.2[,j]<-epidemic.mat.H[,j]-epidemic.mat.H[,j-1]}
epidemic.mat.H.2<-epidemic.mat.H

for(t in 1:(ncol(epidemic.mat.S)-1)){
  epidemic.mat.S [,t+1]<-epidemic.mat.S [,t]  - ((beta.3[[t]]%*%(epidemic.mat.I[,t]+epidemic.mat.Import.I[,t]))*(epidemic.mat.S[,t]/epidemic.mat.N))
  epidemic.mat.E [,t+1]<-epidemic.mat.E [,t]  + (1-q.prob)*((beta.3[[t]]%*%(epidemic.mat.I[,t]+epidemic.mat.Import.I[,t]))*(epidemic.mat.S[,t]/epidemic.mat.N))  - ((1/theta)*epidemic.mat.E[,t])
  epidemic.mat.I [,t+1]<-epidemic.mat.I [,t]  + ((1/theta)*epidemic.mat.E[,t]) - ((1/gamma)*epidemic.mat.I[,t])
  epidemic.mat.Q [,t+1]<-epidemic.mat.Q [,t]  + (q.prob)*((beta.3[[t]]%*%(epidemic.mat.I[,t]+epidemic.mat.Import.I[,t]))*(epidemic.mat.S[,t]/epidemic.mat.N))  - ((1/theta)*epidemic.mat.Q[,t])
  epidemic.mat.H [,t+1]<-epidemic.mat.H [,t]  + ((1/gamma)*epidemic.mat.I[,t]) + ((1/theta)*epidemic.mat.Q[,t])
}
newcase.3<-matrix(NA,ncol=ncol(epidemic.mat.S),nrow=num.metapop)
newcase.3[,1]<-0
for(j in 2:ncol(epidemic.mat.S)){newcase.3[,j]<-epidemic.mat.H[,j]-epidemic.mat.H[,j-1]}
epidemic.mat.H.3<-epidemic.mat.H


for(t in 1:(ncol(epidemic.mat.S)-1)){
  epidemic.mat.S [,t+1]<-epidemic.mat.S [,t]  - ((beta.4[[t]]%*%(epidemic.mat.I[,t]+epidemic.mat.Import.I[,t]))*(epidemic.mat.S[,t]/epidemic.mat.N))
  epidemic.mat.E [,t+1]<-epidemic.mat.E [,t]  + (1-q.prob)*((beta.4[[t]]%*%(epidemic.mat.I[,t]+epidemic.mat.Import.I[,t]))*(epidemic.mat.S[,t]/epidemic.mat.N))  - ((1/theta)*epidemic.mat.E[,t])
  epidemic.mat.I [,t+1]<-epidemic.mat.I [,t]  + ((1/theta)*epidemic.mat.E[,t]) - ((1/gamma)*epidemic.mat.I[,t])
  epidemic.mat.Q [,t+1]<-epidemic.mat.Q [,t]  + (q.prob)*((beta.4[[t]]%*%(epidemic.mat.I[,t]+epidemic.mat.Import.I[,t]))*(epidemic.mat.S[,t]/epidemic.mat.N))  - ((1/theta)*epidemic.mat.Q[,t])
  epidemic.mat.H [,t+1]<-epidemic.mat.H [,t]  + ((1/gamma)*epidemic.mat.I[,t]) + ((1/theta)*epidemic.mat.Q[,t])
}
newcase.4<-matrix(NA,ncol=ncol(epidemic.mat.S),nrow=num.metapop)
newcase.4[,1]<-0
for(j in 2:ncol(epidemic.mat.S)){newcase.4[,j]<-epidemic.mat.H[,j]-epidemic.mat.H[,j-1]}
epidemic.mat.H.4<-epidemic.mat.H



#par(mfrow=c(2,2))
#plot(newcase.2[1,2:(time.duration-6)],type='l',col=2)
#lines(newcase.1[1,2:(time.duration-6)],col=1)
#abline(v=15,col=3)
#plot(newcase.2[2,2:(time.duration-6)],type='l',col=2)
#lines(newcase.1[2,2:(time.duration-6)],col=1)
#abline(v=15,col=3)


##plot(epidemic.mat.H.2[1,2:(time.duration-6)],type='l',col=2)
#lines(epidemic.mat.H.1[1,2:(time.duration-6)],col=1)
#abline(v=15,col=3)
#plot(epidemic.mat.H.2[2,2:(time.duration-6)],type='l',col=2)
#lines(epidemic.mat.H.1[2,2:(time.duration-6)],col=1)
#abline(v=15,col=3)

sum(epidemic.mat.H.1[1,time.duration-6]) # status quo
sum(epidemic.mat.H.2[1,time.duration-6]) # mean
sum(epidemic.mat.H.3[1,time.duration-6]) # LL
sum(epidemic.mat.H.4[1,time.duration-6]) # UL

sum(epidemic.mat.H.1[2,time.duration-6]) # status quo
sum(epidemic.mat.H.2[2,time.duration-6]) # mean
sum(epidemic.mat.H.3[2,time.duration-6]) # LL
sum(epidemic.mat.H.4[2,time.duration-6]) # UL

epidemic.mat.H.1[,time.duration-6]
epidemic.mat.H.2[,time.duration-6]

sum(epidemic.mat.H.1[,time.duration-6])
sum(epidemic.mat.H.2[,time.duration-6])

epidemic.mat.H.2[,time.duration-6]-epidemic.mat.H.1[,time.duration-6]


epidemic.mat.H1.final<-apply(epidemic.mat.H.1,2,sum)
epidemic.mat.H2.final<-apply(epidemic.mat.H.2,2,sum)
epidemic.mat.H3.final<-apply(epidemic.mat.H.3,2,sum)
epidemic.mat.H4.final<-apply(epidemic.mat.H.4,2,sum)
epidemic.mat.H1.final[time.duration-6]
epidemic.mat.H2.final[time.duration-6]
epidemic.mat.H3.final[time.duration-6]
epidemic.mat.H4.final[time.duration-6]

library(ggplot2)
pl.1<-data.frame(Time=1:(time.duration-6), target=newcase.1[1,][1:(time.duration-6)])
pl.2<-data.frame(Time=1:(time.duration-6), target=newcase.1[2,][1:(time.duration-6)])

plot.2.1<-ggplot(pl.1, aes(Time))+ ylab('')+ xlab('')+ 
  geom_line(aes(y=newcase.2[1,][1:(time.duration-6)]),colour='red',size=1)+
  geom_line(aes(y=newcase.1[1,][1:(time.duration-6)]),colour='blue',size=1)+
  geom_vline(xintercept=15,linetype='twodash',color='orange',size=1)+
  theme(axis.title.y = element_text(margin = margin(t = 0, r = 10, b = 0, l = 0)))+
  geom_ribbon(aes(ymin=newcase.3[1,][1:(time.duration-6)], ymax=newcase.4[1,][1:(time.duration-6)]),alpha=0.2,size=3)

plot.2.2<-ggplot(pl.2, aes(Time))+ylab('')+ xlab('')+
  geom_line(aes(y=newcase.2[2,][1:(time.duration-6)]),colour='red',size=1)+
  geom_line(aes(y=newcase.1[2,][1:(time.duration-6)]),colour='blue',size=1)+
  geom_vline(xintercept=15,linetype='twodash',color='orange',size=1)+
  theme(axis.title.y = element_text(margin = margin(t = 0, r = 5, b = 0, l = 0)))+
  geom_ribbon(aes(ymin=newcase.3[2,][1:(time.duration-6)], ymax=newcase.4[2,][1:(time.duration-6)]),alpha=0.2,size=3)


pl.1<-data.frame(Time=1:(time.duration-6), target=epidemic.mat.H.1[1,][1:(time.duration-6)])
pl.2<-data.frame(Time=1:(time.duration-6), target=epidemic.mat.H.1[2,][1:(time.duration-6)])

plot.2.3<-ggplot(pl.1, aes(Time))+ylab('')+ xlab('')+
  geom_line(aes(y=epidemic.mat.H.2[1,][1:(time.duration-6)]),colour='red',size=1)+
  geom_line(aes(y=epidemic.mat.H.1[1,][1:(time.duration-6)]),colour='blue',size=1)+
  geom_vline(xintercept=15,linetype='twodash',color='orange',size=1)+
  theme(axis.title.y = element_text(margin = margin(t = 0, r = 5, b = 0, l = 0)))+
  geom_ribbon(aes(ymin=epidemic.mat.H.3[1,][1:(time.duration-6)], ymax=epidemic.mat.H.4[1,][1:(time.duration-6)]),alpha=0.2,size=3)

plot.2.4<-ggplot(pl.2, aes(Time))+ylab('')+ xlab('')+
  geom_line(aes(y=epidemic.mat.H.2[2,][1:(time.duration-6)]),colour='red',size=1)+
  geom_line(aes(y=epidemic.mat.H.1[2,][1:(time.duration-6)]),colour='blue',size=1)+
  geom_vline(xintercept=15,linetype='twodash',color='orange',size=1)+
  theme(axis.title.y = element_text(margin = margin(t = 0, r = 5, b = 0, l = 0)))+
  geom_ribbon(aes(ymin=epidemic.mat.H.3[2,][1:(time.duration-6)], ymax=epidemic.mat.H.4[2,][1:(time.duration-6)]),alpha=0.2,size=3)

pl.1<-data.frame(Time=1:(time.duration-6), target=contact.rate.per.group.1[[1]][1:(time.duration-6)])
pl.2<-data.frame(Time=1:(time.duration-6), target=contact.rate.per.group.1[[2]][1:(time.duration-6)])

plot.2.5<-ggplot(pl.1, aes(Time))+ylab('')+ xlab('')+
  geom_line(aes(y=contact.rate.per.group.2[[1]][1:(time.duration-6)]),colour='red',size=1)+
  geom_line(aes(y=contact.rate.per.group.1[[1]][1:(time.duration-6)]),colour='blue',size=1)+
  geom_vline(xintercept=15,linetype='twodash',color='orange',size=1)+
  theme(axis.title.y = element_text(margin = margin(t = 0, r = 10, b = 0, l = 0)))+
  ylim(min(contact.rate.per.group.1[[1]][1:(time.duration-6)]), max(contact.rate.per.group.1[[1]][1:(time.duration-6)]*1.3))+
  geom_ribbon(aes(ymin=contact.rate.per.group.3[[1]][1:(time.duration-6)], ymax=contact.rate.per.group.4[[1]][1:(time.duration-6)]),alpha=0.2,size=3)

plot.2.6<-ggplot(pl.2, aes(Time))+ylab('')+ xlab('')+
  geom_line(aes(y=contact.rate.per.group.2[[2]][1:(time.duration-6)]),colour='red',size=1)+
  geom_line(aes(y=contact.rate.per.group.1[[2]][1:(time.duration-6)]),colour='blue',size=1)+
  geom_vline(xintercept=15,linetype='twodash',color='orange',size=1)+
  theme(axis.title.y = element_text(margin = margin(t = 0, r = 25, b = 0, l = 0)))+
  ylim(min(contact.rate.per.group.1[[2]][1:(time.duration-6)]), max(contact.rate.per.group.1[[2]][1:(time.duration-6)]*1.3))+
  geom_ribbon(aes(ymin=contact.rate.per.group.3[[2]][1:(time.duration-6)], ymax=contact.rate.per.group.4[[2]][1:(time.duration-6)]),alpha=0.2,size=3)

library(gridExtra)
grid.arrange(plot.2.1,plot.2.2,plot.2.3,plot.2.4,plot.2.5,plot.2.6,  ncol=2,nrow=3)



raw.foreign<-read.csv('foreign.csv')

pl.3<-data.frame(Time=1:nrow(raw.foreign), target=log(raw.foreign$US))
ggplot(pl.3, aes(Time))+ylim(0,13)+
  geom_line(aes(y=log(raw.foreign$US)),colour='black',size=3)+
  geom_line(aes(y=log(raw.foreign$Spain)),colour='red',size=3)+
  geom_line(aes(y=log(raw.foreign$Italy)),colour='orange',size=3)+
  geom_line(aes(y=log(epidemic.mat.H2.final)[1:49]),colour='blue',linetype='twodash',size=3)+
  geom_ribbon(aes(ymin=log(epidemic.mat.H3.final)[1:49], ymax=log(epidemic.mat.H4.final)[1:49]),alpha=0.2,size=3)

length(raw.foreign$Italy)
length(epidemic.mat.H1.final)



# scenario 2 (school opening at March 2nd) (severe case scenario) #######################################################################################
multiplier.child.to.child<-1.752*(1/0.728) # just 1.752 in mild case scenario 
multiplier.child.to.adult<-1

param.mat.final.1<-parameters.final[2,]
param.mat.final.2<-param.mat.final.1
param.mat.final.2['beta.1.2']<-param.mat.final.1['beta.1.1']*multiplier.child.to.child
param.mat.final.2['beta.cross.1']<-param.mat.final.1['beta.cross.1']*multiplier.child.to.adult

param.mat.final.3<-param.mat.final.1
param.mat.final.3['beta.1.2']<-param.mat.final.1['beta.1.1']*1.701#*(1/0.795)
param.mat.final.3['beta.cross.1']<-param.mat.final.1['beta.cross.1']*multiplier.child.to.adult

param.mat.final.4<-param.mat.final.1
param.mat.final.4['beta.1.2']<-param.mat.final.1['beta.1.1']*1.801#*(1/0.670)
param.mat.final.4['beta.cross.1']<-param.mat.final.1['beta.cross.1']*multiplier.child.to.adult



param.list<-ini.beta.param.list
for(j in 1:2){param.list[[1]][j]<-param.mat.final.1[paste0("beta.1.",j)]  }
for(j in 1:8){param.list[[2]][j]<-param.mat.final.1[paste0("beta.2.",j)]  }
c.rate<-ini.c.rate.fun(split.structure.1,split.structure.2, param.list,as.numeric(param.mat.final.1["beta.cross.1"]),as.numeric(param.mat.final.1["beta.cross.2"]))
contact.rate.mat<-c.rate[[1]]
contact.rate.per.group.1<-list(NA)
contact.rate.per.group.1[[1]]<-rep(1,time.duration)
contact.rate.per.group.1[[2]]<-rep(1,time.duration)
for(i in 1:time.duration){
  contact.rate.per.group.1[[1]][i]<-contact.rate.mat[[i]][1,1]
  contact.rate.per.group.1[[2]][i]<-contact.rate.mat[[i]][2,2]
}
beta.1<-contact.rate.mat

param.list<-ini.beta.param.list
for(j in 1:2){param.list[[1]][j]<-param.mat.final.2[paste0("beta.1.",j)]  }
for(j in 1:8){param.list[[2]][j]<-param.mat.final.2[paste0("beta.2.",j)]}
c.rate<-ini.c.rate.fun(split.structure.1,split.structure.2, param.list,as.numeric(param.mat.final.2["beta.cross.1"]),as.numeric(param.mat.final.2["beta.cross.2"]))
contact.rate.mat<-c.rate[[1]]
contact.rate.per.group.2<-list(NA)
contact.rate.per.group.2[[1]]<-rep(1,time.duration)
contact.rate.per.group.2[[2]]<-rep(1,time.duration)
for(i in 1:time.duration){
  contact.rate.per.group.2[[1]][i]<-contact.rate.mat[[i]][1,1]
  contact.rate.per.group.2[[2]][i]<-contact.rate.mat[[i]][2,2]
}
beta.2<-contact.rate.mat

param.list<-ini.beta.param.list
for(j in 1:2){param.list[[1]][j]<-param.mat.final.3[paste0("beta.1.",j)]  }
for(j in 1:8){param.list[[2]][j]<-param.mat.final.3[paste0("beta.2.",j)]}
c.rate<-ini.c.rate.fun(split.structure.1,split.structure.2, param.list,as.numeric(param.mat.final.3["beta.cross.1"]),as.numeric(param.mat.final.3["beta.cross.2"]))
contact.rate.mat<-c.rate[[1]]
contact.rate.per.group.3<-list(NA)
contact.rate.per.group.3[[1]]<-rep(1,time.duration)
contact.rate.per.group.3[[2]]<-rep(1,time.duration)
for(i in 1:time.duration){
  contact.rate.per.group.3[[1]][i]<-contact.rate.mat[[i]][1,1]
  contact.rate.per.group.3[[2]][i]<-contact.rate.mat[[i]][2,2]
}
beta.3<-contact.rate.mat

param.list<-ini.beta.param.list
for(j in 1:2){param.list[[1]][j]<-param.mat.final.4[paste0("beta.1.",j)]  }
for(j in 1:8){param.list[[2]][j]<-param.mat.final.4[paste0("beta.2.",j)]}
c.rate<-ini.c.rate.fun(split.structure.1,split.structure.2, param.list,as.numeric(param.mat.final.4["beta.cross.1"]),as.numeric(param.mat.final.4["beta.cross.2"]))
contact.rate.mat<-c.rate[[1]]
contact.rate.per.group.4<-list(NA)
contact.rate.per.group.4[[1]]<-rep(1,time.duration)
contact.rate.per.group.4[[2]]<-rep(1,time.duration)
for(i in 1:time.duration){
  contact.rate.per.group.4[[1]][i]<-contact.rate.mat[[i]][1,1]
  contact.rate.per.group.4[[2]][i]<-contact.rate.mat[[i]][2,2]
}
beta.4<-contact.rate.mat


# parameters
theta<- 5.5-1   # incubation period (day)
gamma <- 4.8+1 #detection time (from infectious to isolation) median value from Ki et al 2020
q.prob <-0.04  # quarantine probability of exposed individuals


# simulation matrix structure 
epidemic.mat.S<-matrix(NA,ncol=time.duration,nrow=num.metapop)
epidemic.mat.E<-matrix(NA,ncol=time.duration,nrow=num.metapop)
epidemic.mat.I<-matrix(NA,ncol=time.duration,nrow=num.metapop)
epidemic.mat.Q<-matrix(NA,ncol=time.duration,nrow=num.metapop)
epidemic.mat.H<-matrix(NA,ncol=time.duration,nrow=num.metapop)
epidemic.mat.N<-matrix(c(pop$y2020[2]+pop$y2020[3],pop$y2020[1]-pop$y2020[2]-pop$y2020[3]),ncol=1,nrow=num.metapop)

epidemic.mat.Import.I<-matrix(NA,ncol=time.duration,nrow=num.metapop)
for(t in 1:time.duration){epidemic.mat.Import.I[,t]<-c(0,reported.imported.case[t+1]*gamma)}


# initial value 
epidemic.mat.S[,1]<-c(pop$y2020[2]+pop$y2020[3],pop$y2020[1]-pop$y2020[2]-pop$y2020[3])
epidemic.mat.E[,1]<-0
epidemic.mat.I[,1]<-c(0,3)
epidemic.mat.Q[,1]<-0 #round(c(264*((pop$y2020[2]+pop$y2020[3])/pop$y2020[1]),264*(1-((pop$y2020[2]+pop$y2020[3])/pop$y2020[1]))))
epidemic.mat.H[,1]<-1



for(t in 1:(ncol(epidemic.mat.S)-1)){
  epidemic.mat.S [,t+1]<-epidemic.mat.S [,t]  - ((beta.1[[t]]%*%(epidemic.mat.I[,t]+epidemic.mat.Import.I[,t]))*(epidemic.mat.S[,t]/epidemic.mat.N))
  epidemic.mat.E [,t+1]<-epidemic.mat.E [,t]  + (1-q.prob)*((beta.1[[t]]%*%(epidemic.mat.I[,t]+epidemic.mat.Import.I[,t]))*(epidemic.mat.S[,t]/epidemic.mat.N))  - ((1/theta)*epidemic.mat.E[,t])
  epidemic.mat.I [,t+1]<-epidemic.mat.I [,t]  + ((1/theta)*epidemic.mat.E[,t]) - ((1/gamma)*epidemic.mat.I[,t])
  epidemic.mat.Q [,t+1]<-epidemic.mat.Q [,t]  + (q.prob)*((beta.1[[t]]%*%(epidemic.mat.I[,t]+epidemic.mat.Import.I[,t]))*(epidemic.mat.S[,t]/epidemic.mat.N))  - ((1/theta)*epidemic.mat.Q[,t])
  epidemic.mat.H [,t+1]<-epidemic.mat.H [,t]  + ((1/gamma)*epidemic.mat.I[,t]) + ((1/theta)*epidemic.mat.Q[,t])
}
newcase.1<-matrix(NA,ncol=ncol(epidemic.mat.S),nrow=num.metapop)
newcase.1[,1]<-0
for(j in 2:ncol(epidemic.mat.S)){newcase.1[,j]<-epidemic.mat.H[,j]-epidemic.mat.H[,j-1]}
epidemic.mat.H.1<-epidemic.mat.H


for(t in 1:(ncol(epidemic.mat.S)-1)){
  epidemic.mat.S [,t+1]<-epidemic.mat.S [,t]  - ((beta.2[[t]]%*%(epidemic.mat.I[,t]+epidemic.mat.Import.I[,t]))*(epidemic.mat.S[,t]/epidemic.mat.N))
  epidemic.mat.E [,t+1]<-epidemic.mat.E [,t]  + (1-q.prob)*((beta.2[[t]]%*%(epidemic.mat.I[,t]+epidemic.mat.Import.I[,t]))*(epidemic.mat.S[,t]/epidemic.mat.N))  - ((1/theta)*epidemic.mat.E[,t])
  epidemic.mat.I [,t+1]<-epidemic.mat.I [,t]  + ((1/theta)*epidemic.mat.E[,t]) - ((1/gamma)*epidemic.mat.I[,t])
  epidemic.mat.Q [,t+1]<-epidemic.mat.Q [,t]  + (q.prob)*((beta.2[[t]]%*%(epidemic.mat.I[,t]+epidemic.mat.Import.I[,t]))*(epidemic.mat.S[,t]/epidemic.mat.N))  - ((1/theta)*epidemic.mat.Q[,t])
  epidemic.mat.H [,t+1]<-epidemic.mat.H [,t]  + ((1/gamma)*epidemic.mat.I[,t]) + ((1/theta)*epidemic.mat.Q[,t])
}
newcase.2<-matrix(NA,ncol=ncol(epidemic.mat.S),nrow=num.metapop)
newcase.2[,1]<-0
for(j in 2:ncol(epidemic.mat.S)){newcase.2[,j]<-epidemic.mat.H[,j]-epidemic.mat.H[,j-1]}
epidemic.mat.H.2<-epidemic.mat.H

for(t in 1:(ncol(epidemic.mat.S)-1)){
  epidemic.mat.S [,t+1]<-epidemic.mat.S [,t]  - ((beta.3[[t]]%*%(epidemic.mat.I[,t]+epidemic.mat.Import.I[,t]))*(epidemic.mat.S[,t]/epidemic.mat.N))
  epidemic.mat.E [,t+1]<-epidemic.mat.E [,t]  + (1-q.prob)*((beta.3[[t]]%*%(epidemic.mat.I[,t]+epidemic.mat.Import.I[,t]))*(epidemic.mat.S[,t]/epidemic.mat.N))  - ((1/theta)*epidemic.mat.E[,t])
  epidemic.mat.I [,t+1]<-epidemic.mat.I [,t]  + ((1/theta)*epidemic.mat.E[,t]) - ((1/gamma)*epidemic.mat.I[,t])
  epidemic.mat.Q [,t+1]<-epidemic.mat.Q [,t]  + (q.prob)*((beta.3[[t]]%*%(epidemic.mat.I[,t]+epidemic.mat.Import.I[,t]))*(epidemic.mat.S[,t]/epidemic.mat.N))  - ((1/theta)*epidemic.mat.Q[,t])
  epidemic.mat.H [,t+1]<-epidemic.mat.H [,t]  + ((1/gamma)*epidemic.mat.I[,t]) + ((1/theta)*epidemic.mat.Q[,t])
}
newcase.3<-matrix(NA,ncol=ncol(epidemic.mat.S),nrow=num.metapop)
newcase.3[,1]<-0
for(j in 2:ncol(epidemic.mat.S)){newcase.3[,j]<-epidemic.mat.H[,j]-epidemic.mat.H[,j-1]}
epidemic.mat.H.3<-epidemic.mat.H


for(t in 1:(ncol(epidemic.mat.S)-1)){
  epidemic.mat.S [,t+1]<-epidemic.mat.S [,t]  - ((beta.4[[t]]%*%(epidemic.mat.I[,t]+epidemic.mat.Import.I[,t]))*(epidemic.mat.S[,t]/epidemic.mat.N))
  epidemic.mat.E [,t+1]<-epidemic.mat.E [,t]  + (1-q.prob)*((beta.4[[t]]%*%(epidemic.mat.I[,t]+epidemic.mat.Import.I[,t]))*(epidemic.mat.S[,t]/epidemic.mat.N))  - ((1/theta)*epidemic.mat.E[,t])
  epidemic.mat.I [,t+1]<-epidemic.mat.I [,t]  + ((1/theta)*epidemic.mat.E[,t]) - ((1/gamma)*epidemic.mat.I[,t])
  epidemic.mat.Q [,t+1]<-epidemic.mat.Q [,t]  + (q.prob)*((beta.4[[t]]%*%(epidemic.mat.I[,t]+epidemic.mat.Import.I[,t]))*(epidemic.mat.S[,t]/epidemic.mat.N))  - ((1/theta)*epidemic.mat.Q[,t])
  epidemic.mat.H [,t+1]<-epidemic.mat.H [,t]  + ((1/gamma)*epidemic.mat.I[,t]) + ((1/theta)*epidemic.mat.Q[,t])
}
newcase.4<-matrix(NA,ncol=ncol(epidemic.mat.S),nrow=num.metapop)
newcase.4[,1]<-0
for(j in 2:ncol(epidemic.mat.S)){newcase.4[,j]<-epidemic.mat.H[,j]-epidemic.mat.H[,j-1]}
epidemic.mat.H.4<-epidemic.mat.H



par(mfrow=c(2,2))
plot(newcase.2[1,2:(time.duration-6)],type='l',col=2)
lines(newcase.1[1,2:(time.duration-6)],col=1)
abline(v=time.semester.start,col=3)
plot(newcase.2[2,2:(time.duration-6)],type='l',col=2)
lines(newcase.1[2,2:(time.duration-6)],col=1)
abline(v=time.semester.start,col=3)


plot(epidemic.mat.H.2[1,2:(time.duration-6)],type='l',col=2)
lines(epidemic.mat.H.1[1,2:(time.duration-6)],col=1)
abline(v=time.semester.start,col=3)
plot(epidemic.mat.H.2[2,2:(time.duration-6)],type='l',col=2)
lines(epidemic.mat.H.1[2,2:(time.duration-6)],col=1)
abline(v=time.semester.start,col=3)


epidemic.mat.H.1[,time.duration-6]
epidemic.mat.H.2[,time.duration-6]

sum(epidemic.mat.H.1[1,time.duration-6]) # status quo
sum(epidemic.mat.H.2[1,time.duration-6]) # mean
sum(epidemic.mat.H.3[1,time.duration-6]) # LL
sum(epidemic.mat.H.4[1,time.duration-6]) # UL

sum(epidemic.mat.H.1[2,time.duration-6]) # status quo
sum(epidemic.mat.H.2[2,time.duration-6]) # mean
sum(epidemic.mat.H.3[2,time.duration-6]) # LL
sum(epidemic.mat.H.4[2,time.duration-6]) # UL


epidemic.mat.H.2[,time.duration-6]-epidemic.mat.H.1[,time.duration-6]

epidemic.mat.H1.final<-apply(epidemic.mat.H.1,2,sum)
epidemic.mat.H2.final<-apply(epidemic.mat.H.2,2,sum)
epidemic.mat.H3.final<-apply(epidemic.mat.H.3,2,sum)
epidemic.mat.H4.final<-apply(epidemic.mat.H.4,2,sum)

epidemic.mat.H1.final[time.duration-6]
epidemic.mat.H2.final[time.duration-6]
epidemic.mat.H3.final[time.duration-6]
epidemic.mat.H4.final[time.duration-6]

library(ggplot2)
pl.1<-data.frame(Time=1:(time.duration-6), target=newcase.1[1,][1:(time.duration-6)])
pl.2<-data.frame(Time=1:(time.duration-6), target=newcase.1[2,][1:(time.duration-6)])

plot.1.1<-ggplot(pl.1, aes(Time))+ ylab('')+ xlab('')+ 
  geom_line(aes(y=newcase.2[1,][1:(time.duration-6)]),colour='red',size=1)+
  geom_line(aes(y=newcase.1[1,][1:(time.duration-6)]),colour='blue',size=1)+
  geom_vline(xintercept=20,linetype='twodash',color='orange',size=1)+
  theme(axis.title.y = element_text(margin = margin(t = 0, r = 20, b = 0, l = 0)))+
  geom_ribbon(aes(ymin=newcase.3[1,][1:(time.duration-6)], ymax=newcase.4[1,][1:(time.duration-6)]),alpha=0.2,size=3)

plot.1.2<-ggplot(pl.2, aes(Time))+ylab('')+ xlab('')+
  geom_line(aes(y=newcase.2[2,][1:(time.duration-6)]),colour='red',size=1)+
  geom_line(aes(y=newcase.1[2,][1:(time.duration-6)]),colour='blue',size=1)+
  geom_vline(xintercept=20,linetype='twodash',color='orange',size=1)+
  theme(axis.title.y = element_text(margin = margin(t = 0, r = 15, b = 0, l = 0)))+
  geom_ribbon(aes(ymin=newcase.3[2,][1:(time.duration-6)], ymax=newcase.4[2,][1:(time.duration-6)]),alpha=0.2,size=3)


pl.1<-data.frame(Time=1:(time.duration-6), target=epidemic.mat.H.1[1,][1:(time.duration-6)])
pl.2<-data.frame(Time=1:(time.duration-6), target=epidemic.mat.H.1[2,][1:(time.duration-6)])

plot.1.3<-ggplot(pl.1, aes(Time))+ylab('')+ xlab('')+
  geom_line(aes(y=epidemic.mat.H.2[1,][1:(time.duration-6)]),colour='red',size=1)+
  geom_line(aes(y=epidemic.mat.H.1[1,][1:(time.duration-6)]),colour='blue',size=1)+
  geom_vline(xintercept=20,linetype='twodash',color='orange',size=1)+
  theme(axis.title.y = element_text(margin = margin(t = 0, r = 15, b = 0, l = 0)))+
  geom_ribbon(aes(ymin=epidemic.mat.H.3[1,][1:(time.duration-6)], ymax=epidemic.mat.H.4[1,][1:(time.duration-6)]),alpha=0.2,size=3)

plot.1.4<-ggplot(pl.2, aes(Time))+ylab('')+ xlab('')+
  geom_line(aes(y=epidemic.mat.H.2[2,][1:(time.duration-6)]),colour='red',size=1)+
  geom_line(aes(y=epidemic.mat.H.1[2,][1:(time.duration-6)]),colour='blue',size=1)+
  geom_vline(xintercept=20,linetype='twodash',color='orange',size=1)+
  theme(axis.title.y = element_text(margin = margin(t = 0, r = 5, b = 0, l = 0)))+
  geom_ribbon(aes(ymin=epidemic.mat.H.3[2,][1:(time.duration-6)], ymax=epidemic.mat.H.4[2,][1:(time.duration-6)]),alpha=0.2,size=3)

pl.1<-data.frame(Time=1:(time.duration-6), target=contact.rate.per.group.1[[1]][1:(time.duration-6)])
pl.2<-data.frame(Time=1:(time.duration-6), target=contact.rate.per.group.1[[2]][1:(time.duration-6)])

plot.1.5<-ggplot(pl.1, aes(Time))+ylab('')+ xlab('')+
  geom_line(aes(y=contact.rate.per.group.2[[1]][1:(time.duration-6)]),colour='red',size=1)+
  geom_line(aes(y=contact.rate.per.group.1[[1]][1:(time.duration-6)]),colour='blue',size=1)+
  geom_vline(xintercept=20,linetype='twodash',color='orange',size=1)+
  theme(axis.title.y = element_text(margin = margin(t = 0, r = 7, b = 0, l = 0)))+
  geom_ribbon(aes(ymin=contact.rate.per.group.3[[1]][1:(time.duration-6)], ymax=contact.rate.per.group.4[[1]][1:(time.duration-6)]),alpha=0.2,size=3)

plot.1.6<-ggplot(pl.2, aes(Time))+ylab('')+ xlab('')+
  geom_line(aes(y=contact.rate.per.group.2[[2]][1:(time.duration-6)]),colour='red',size=1)+
  geom_line(aes(y=contact.rate.per.group.1[[2]][1:(time.duration-6)]),colour='blue',size=1)+
  geom_vline(xintercept=20,linetype='twodash',color='orange',size=1)+
  theme(axis.title.y = element_text(margin = margin(t = 0, r = 20, b = 0, l = 0)))+
  ylim(min(contact.rate.per.group.1[[2]][1:(time.duration-6)]), max(contact.rate.per.group.1[[2]][1:(time.duration-6)]*1.3))+
  geom_ribbon(aes(ymin=contact.rate.per.group.3[[2]][1:(time.duration-6)], ymax=contact.rate.per.group.4[[2]][1:(time.duration-6)]),alpha=0.2,size=3)

library(gridExtra)
grid.arrange(plot.1.1,plot.1.2,plot.1.3,plot.1.4,plot.1.5,plot.1.6,  ncol=2,nrow=3)

raw.foreign<-read.csv('foreign.csv',stringsAsFactors = F)

pl.3<-data.frame(Time=1:nrow(raw.foreign), target=log(raw.foreign$US))
ggplot(pl.3, aes(Time))+ylim(0,13)+
  geom_line(aes(y=log(raw.foreign$US)),colour='black',size=3)+
  geom_line(aes(y=log(raw.foreign$Spain)),colour='red',size=3)+
  geom_line(aes(y=log(raw.foreign$Italy)),colour='orange',size=3)+
  geom_line(aes(y=log(epidemic.mat.H1.final)[1:49]),colour='blue',size=3)


pl.3<-data.frame(Time=1:nrow(raw.foreign), target=log(raw.foreign$US))
ggplot(pl.3, aes(Time))+ylim(0,13)+
  geom_line(aes(y=log(raw.foreign$US)),colour='black',size=3)+
  geom_line(aes(y=log(raw.foreign$Spain)),colour='red',size=3)+
  geom_line(aes(y=log(raw.foreign$Italy)),colour='orange',size=3)+
  geom_line(aes(y=log(epidemic.mat.H2.final)[1:49]),colour='blue',linetype='twodash',size=3)+
  geom_ribbon(aes(ymin=log(epidemic.mat.H3.final)[1:49], ymax=log(epidemic.mat.H4.final)[1:49]),alpha=0.2,size=3)


# scenario 3-1 (changing detection time) #######################################################################################
param.mat.final.1<-parameters.final[2,]
param.mat.final.2<-param.mat.final.1


param.list<-ini.beta.param.list
for(j in 1:2){param.list[[1]][j]<-param.mat.final.1[paste0("beta.1.",j)]  }
for(j in 1:8){param.list[[2]][j]<-param.mat.final.1[paste0("beta.2.",j)]  }
c.rate<-ini.c.rate.fun(split.structure.1,split.structure.2, param.list,as.numeric(param.mat.final.1["beta.cross.1"]),as.numeric(param.mat.final.1["beta.cross.2"]))
contact.rate.mat<-c.rate[[1]]
contact.rate.per.group.1<-list(NA)
contact.rate.per.group.1[[1]]<-rep(1,time.duration)
contact.rate.per.group.1[[2]]<-rep(1,time.duration)
for(i in 1:time.duration){
  contact.rate.per.group.1[[1]][i]<-contact.rate.mat[[i]][1,1]
  contact.rate.per.group.1[[2]][i]<-contact.rate.mat[[i]][2,2]
}
beta.1<-contact.rate.mat

param.list<-ini.beta.param.list
for(j in 1:2){param.list[[1]][j]<-param.mat.final.2[paste0("beta.1.",j)]  }
for(j in 1:8){param.list[[2]][j]<-param.mat.final.2[paste0("beta.2.",j)]}
c.rate<-ini.c.rate.fun(split.structure.1,split.structure.2, param.list,as.numeric(param.mat.final.2["beta.cross.1"]),as.numeric(param.mat.final.2["beta.cross.2"]))
contact.rate.mat<-c.rate[[1]]
contact.rate.per.group.2<-list(NA)
contact.rate.per.group.2[[1]]<-rep(1,time.duration)
contact.rate.per.group.2[[2]]<-rep(1,time.duration)
for(i in 1:time.duration){
  contact.rate.per.group.2[[1]][i]<-contact.rate.mat[[i]][1,1]
  contact.rate.per.group.2[[2]][i]<-contact.rate.mat[[i]][2,2]
}
beta.2<-contact.rate.mat


# parameters
theta.1<- 5.5-1   # incubation period (day)
gamma.1 <- 4.8+1 #detection time (from infectious to isolation) median value from Ki et al 2020
q.prob.1 <-0.04  # quarantine probability of exposed individuals

theta.2<- 5.5-1   # incubation period (day)
gamma.2 <- 8.09+1 #detection time (from infectious to isolation) median value from Ki et al 2020
q.prob.2 <-0.04/2  # quarantine probability of exposed individuals


# simulation matrix structure 
epidemic.mat.S<-matrix(NA,ncol=time.duration,nrow=num.metapop)
epidemic.mat.E<-matrix(NA,ncol=time.duration,nrow=num.metapop)
epidemic.mat.I<-matrix(NA,ncol=time.duration,nrow=num.metapop)
epidemic.mat.Q<-matrix(NA,ncol=time.duration,nrow=num.metapop)
epidemic.mat.H<-matrix(NA,ncol=time.duration,nrow=num.metapop)
epidemic.mat.N<-matrix(c(pop$y2020[2]+pop$y2020[3],pop$y2020[1]-pop$y2020[2]-pop$y2020[3]),ncol=1,nrow=num.metapop)

epidemic.mat.Import.I<-matrix(NA,ncol=time.duration,nrow=num.metapop)
for(t in 1:time.duration){epidemic.mat.Import.I[,t]<-c(0,reported.imported.case[t+1]*gamma)}


# initial value 
epidemic.mat.S[,1]<-c(pop$y2020[2]+pop$y2020[3],pop$y2020[1]-pop$y2020[2]-pop$y2020[3])
epidemic.mat.E[,1]<-0
epidemic.mat.I[,1]<-c(0,3)
epidemic.mat.Q[,1]<-0 #round(c(264*((pop$y2020[2]+pop$y2020[3])/pop$y2020[1]),264*(1-((pop$y2020[2]+pop$y2020[3])/pop$y2020[1]))))
epidemic.mat.H[,1]<-1



for(t in 1:(ncol(epidemic.mat.S)-1)){
  epidemic.mat.S [,t+1]<-epidemic.mat.S [,t]  - ((beta.1[[t]]%*%(epidemic.mat.I[,t]+epidemic.mat.Import.I[,t]))*(epidemic.mat.S[,t]/epidemic.mat.N))
  epidemic.mat.E [,t+1]<-epidemic.mat.E [,t]  + (1-q.prob)*((beta.1[[t]]%*%(epidemic.mat.I[,t]+epidemic.mat.Import.I[,t]))*(epidemic.mat.S[,t]/epidemic.mat.N))  - ((1/theta)*epidemic.mat.E[,t])
  epidemic.mat.I [,t+1]<-epidemic.mat.I [,t]  + ((1/theta)*epidemic.mat.E[,t]) - ((1/gamma)*epidemic.mat.I[,t])
  epidemic.mat.Q [,t+1]<-epidemic.mat.Q [,t]  + (q.prob)*((beta.1[[t]]%*%(epidemic.mat.I[,t]+epidemic.mat.Import.I[,t]))*(epidemic.mat.S[,t]/epidemic.mat.N))  - ((1/theta)*epidemic.mat.Q[,t])
  epidemic.mat.H [,t+1]<-epidemic.mat.H [,t]  + ((1/gamma)*epidemic.mat.I[,t]) + ((1/theta)*epidemic.mat.Q[,t])
}
newcase.1<-matrix(NA,ncol=ncol(epidemic.mat.S),nrow=num.metapop)
newcase.1[,1]<-0
for(j in 2:ncol(epidemic.mat.S)){newcase.1[,j]<-epidemic.mat.H[,j]-epidemic.mat.H[,j-1]}
epidemic.mat.H.1<-epidemic.mat.H


for(t in 1:(ncol(epidemic.mat.S)-1)){
  epidemic.mat.S [,t+1]<-epidemic.mat.S [,t]  - ((beta.2[[t]]%*%(epidemic.mat.I[,t]+epidemic.mat.Import.I[,t]))*(epidemic.mat.S[,t]/epidemic.mat.N))
  epidemic.mat.E [,t+1]<-epidemic.mat.E [,t]  + (1-q.prob.2)*((beta.2[[t]]%*%(epidemic.mat.I[,t]+epidemic.mat.Import.I[,t]))*(epidemic.mat.S[,t]/epidemic.mat.N))  - ((1/theta.2)*epidemic.mat.E[,t])
  epidemic.mat.I [,t+1]<-epidemic.mat.I [,t]  + ((1/theta.2)*epidemic.mat.E[,t]) - ((1/gamma.2)*epidemic.mat.I[,t])
  epidemic.mat.Q [,t+1]<-epidemic.mat.Q [,t]  + (q.prob.2)*((beta.2[[t]]%*%(epidemic.mat.I[,t]+epidemic.mat.Import.I[,t]))*(epidemic.mat.S[,t]/epidemic.mat.N))  - ((1/theta.2)*epidemic.mat.Q[,t])
  epidemic.mat.H [,t+1]<-epidemic.mat.H [,t]  + ((1/gamma.2)*epidemic.mat.I[,t]) + ((1/theta.2)*epidemic.mat.Q[,t])
}
newcase.2<-matrix(NA,ncol=ncol(epidemic.mat.S),nrow=num.metapop)
newcase.2[,1]<-0
for(j in 2:ncol(epidemic.mat.S)){newcase.2[,j]<-epidemic.mat.H[,j]-epidemic.mat.H[,j-1]}
epidemic.mat.H.2<-epidemic.mat.H

epidemic.mat.H.1[,time.duration-6]
epidemic.mat.H.2[,time.duration-6]

sum(epidemic.mat.H.1[1,time.duration-6])
sum(epidemic.mat.H.2[1,time.duration-6])

sum(epidemic.mat.H.1[2,time.duration-6])
sum(epidemic.mat.H.2[2,time.duration-6])

epidemic.mat.H.2[,time.duration-6]-epidemic.mat.H.1[,time.duration-6]


epidemic.mat.H1.final<-apply(epidemic.mat.H.1,2,sum)
epidemic.mat.H2.final<-apply(epidemic.mat.H.2,2,sum)

epidemic.mat.H1.final[time.duration-6]
epidemic.mat.H2.final[time.duration-6]

library(ggplot2)

pl.1<-data.frame(Time=1:(time.duration-6), target=newcase.1[1,][1:(time.duration-6)])
pl.2<-data.frame(Time=1:(time.duration-6), target=newcase.1[2,][1:(time.duration-6)])

plot.2.1<-ggplot(pl.1, aes(Time))+ ylab('')+ xlab('')+ 
  geom_line(aes(y=newcase.2[1,][1:(time.duration-6)]),colour='red',size=1)+
  geom_line(aes(y=newcase.1[1,][1:(time.duration-6)]),colour='blue',size=1)+
  geom_vline(xintercept=15,linetype='twodash',color='orange',size=1)+
  theme(axis.title.y = element_text(margin = margin(t = 0, r = 10, b = 0, l = 0)))

plot.2.2<-ggplot(pl.2, aes(Time))+ylab('')+ xlab('')+
  geom_line(aes(y=newcase.2[2,][1:(time.duration-6)]),colour='red',size=1)+
  geom_line(aes(y=newcase.1[2,][1:(time.duration-6)]),colour='blue',size=1)+
  geom_vline(xintercept=15,linetype='twodash',color='orange',size=1)+
  theme(axis.title.y = element_text(margin = margin(t = 0, r = 5, b = 0, l = 0)))


pl.1<-data.frame(Time=1:(time.duration-6), target=epidemic.mat.H.1[1,][1:(time.duration-6)])
pl.2<-data.frame(Time=1:(time.duration-6), target=epidemic.mat.H.1[2,][1:(time.duration-6)])

plot.2.3<-ggplot(pl.1, aes(Time))+ylab('')+ xlab('')+
  geom_line(aes(y=epidemic.mat.H.2[1,][1:(time.duration-6)]),colour='red',size=1)+
  geom_line(aes(y=epidemic.mat.H.1[1,][1:(time.duration-6)]),colour='blue',size=1)+
  geom_vline(xintercept=15,linetype='twodash',color='orange',size=1)+
  theme(axis.title.y = element_text(margin = margin(t = 0, r = 5, b = 0, l = 0)))

plot.2.4<-ggplot(pl.2, aes(Time))+ylab('')+ xlab('')+
  geom_line(aes(y=epidemic.mat.H.2[2,][1:(time.duration-6)]),colour='red',size=1)+
  geom_line(aes(y=epidemic.mat.H.1[2,][1:(time.duration-6)]),colour='blue',size=1)+
  geom_vline(xintercept=15,linetype='twodash',color='orange',size=1)+
  theme(axis.title.y = element_text(margin = margin(t = 0, r = 5, b = 0, l = 0)))

pl.1<-data.frame(Time=1:(time.duration-6), target=contact.rate.per.group.1[[1]][1:(time.duration-6)])
pl.2<-data.frame(Time=1:(time.duration-6), target=contact.rate.per.group.1[[2]][1:(time.duration-6)])

plot.2.5<-ggplot(pl.1, aes(Time))+ylab('')+ xlab('')+
  geom_line(aes(y=contact.rate.per.group.2[[1]][1:(time.duration-6)]),colour='red',size=1)+
  geom_line(aes(y=contact.rate.per.group.1[[1]][1:(time.duration-6)]),colour='blue',size=1)+
  geom_vline(xintercept=15,linetype='twodash',color='orange',size=1)+
  theme(axis.title.y = element_text(margin = margin(t = 0, r = 10, b = 0, l = 0)))+
  ylim(min(contact.rate.per.group.1[[1]][1:(time.duration-6)]), max(contact.rate.per.group.1[[1]][1:(time.duration-6)]*1.3))
  
plot.2.6<-ggplot(pl.2, aes(Time))+ylab('')+ xlab('')+
  geom_line(aes(y=contact.rate.per.group.2[[2]][1:(time.duration-6)]),colour='red',size=1)+
  geom_line(aes(y=contact.rate.per.group.1[[2]][1:(time.duration-6)]),colour='blue',size=1)+
  geom_vline(xintercept=15,linetype='twodash',color='orange',size=1)+
  theme(axis.title.y = element_text(margin = margin(t = 0, r = 25, b = 0, l = 0)))+
  ylim(min(contact.rate.per.group.1[[2]][1:(time.duration-6)]), max(contact.rate.per.group.1[[2]][1:(time.duration-6)]*1.3))
  
library(gridExtra)
grid.arrange(plot.2.1,plot.2.2,plot.2.3,plot.2.4,plot.2.5,plot.2.6,  ncol=2,nrow=3)



raw.foreign<-read.csv('foreign.csv')

pl.3<-data.frame(Time=1:nrow(raw.foreign), target=log(raw.foreign$US))
ggplot(pl.3, aes(Time))+ylim(0,13)+
  geom_line(aes(y=log(raw.foreign$US)),colour='black',size=3)+
  geom_line(aes(y=log(raw.foreign$Spain)),colour='red',size=3)+
  geom_line(aes(y=log(raw.foreign$Italy)),colour='orange',size=3)+
  geom_line(aes(y=log(epidemic.mat.H2.final)[1:49]),colour='blue',linetype='twodash',size=3)


# scenario 3 (contour plot) #######################################################################################

temp<-matrix(NA,ncol=5,nrow=1)
colnames(temp)<-c('gamma','qprob','changeincase_all','changeincase_19','changeincase_20')
temp[1:3]<-c(4.8+1,0.04,0)
temp<-as.data.frame(temp)

sce.3.results.mat<-matrix(NA,ncol=5,nrow=10000)
colnames(sce.3.results.mat)<-c('gamma','qprob','changeincase_all','changeincase_19','changeincase_20')

for(x in 1:100){for (y in 1:100){
  
  gamma.change <-seq(from=-2,to=2,length.out=100)
  q.prob.change <- seq(from=-0.02,to=0.06,length.out=100)
  
  param.mat.final.1<-parameters.final[2,]
  param.mat.final.2<-param.mat.final.1
  
  
  param.list<-ini.beta.param.list
  for(j in 1:2){param.list[[1]][j]<-param.mat.final.1[paste0("beta.1.",j)]  }
  for(j in 1:8){param.list[[2]][j]<-param.mat.final.1[paste0("beta.2.",j)]  }
  
  c.rate<-ini.c.rate.fun(split.structure.1, split.structure.2, param.list,as.numeric(param.mat.final.1["beta.cross.1"]),as.numeric(param.mat.final.1["beta.cross.2"]))
  contact.rate.mat<-c.rate[[1]]
  
  beta.1<-contact.rate.mat
  
  param.list<-ini.beta.param.list
  for(j in 1:2){param.list[[1]][j]<-param.mat.final.2[paste0("beta.1.",j)]  }
  for(j in 1:8){param.list[[2]][j]<-param.mat.final.2[paste0("beta.2.",j)]}
  
  
  c.rate<-ini.c.rate.fun(split.structure.1, split.structure.2, param.list,as.numeric(param.mat.final.2["beta.cross.1"]),as.numeric(param.mat.final.2["beta.cross.2"]))
  contact.rate.mat<-c.rate[[1]]
  
  
  beta.2<-contact.rate.mat
  
  
  # parameters
  theta.1<- 5.5-1   # incubation period (day)
  gamma.1 <- 4.8+1 #detection time (from infectious to isolation) median value from Ki et al 2020
  q.prob.1 <-0.04  # quarantine probability of exposed individuals
  
  
  
  theta.2<- 5.5-1   # incubation period (day)
  gamma.2 <- 4.8+1 +gamma.change[x]   #detection time (from infectious to isolation) median value from Ki et al 2020
  q.prob.2 <-0.04 +q.prob.change[y]  # quarantine probability of exposed individuals
  
  # simulation matrix structure 
  epidemic.mat.S<-matrix(NA,ncol=time.duration,nrow=num.metapop)
  epidemic.mat.E<-matrix(NA,ncol=time.duration,nrow=num.metapop)
  epidemic.mat.I<-matrix(NA,ncol=time.duration,nrow=num.metapop)
  epidemic.mat.Q<-matrix(NA,ncol=time.duration,nrow=num.metapop)
  epidemic.mat.H<-matrix(NA,ncol=time.duration,nrow=num.metapop)
  epidemic.mat.N<-matrix(c(pop$y2020[2]+pop$y2020[3],pop$y2020[1]-pop$y2020[2]-pop$y2020[3]),ncol=1,nrow=num.metapop)
  
  
  # initial value 
  epidemic.mat.S[,1]<-c(pop$y2020[2]+pop$y2020[3],pop$y2020[1]-pop$y2020[2]-pop$y2020[3])
  epidemic.mat.E[,1]<-0
  epidemic.mat.I[,1]<-c(0,3)
  epidemic.mat.Q[,1]<-0 #round(c(264*((pop$y2020[2]+pop$y2020[3])/pop$y2020[1]),264*(1-((pop$y2020[2]+pop$y2020[3])/pop$y2020[1]))))
  epidemic.mat.H[,1]<-1
  
  epidemic.mat.Import.I<-matrix(NA,ncol=time.duration,nrow=num.metapop)
  for(t in 1:time.duration){epidemic.mat.Import.I[,t]<-c(0,reported.imported.case[t+1]*gamma.1)}
  
  for(t in 1:(ncol(epidemic.mat.S)-1)){
    epidemic.mat.S [,t+1]<-epidemic.mat.S [,t]  - ((beta.1[[t]]%*%(epidemic.mat.I[,t]+epidemic.mat.Import.I[,t]))*(epidemic.mat.S[,t]/epidemic.mat.N))
    epidemic.mat.E [,t+1]<-epidemic.mat.E [,t]  + (1-q.prob.1)*((beta.1[[t]]%*%(epidemic.mat.I[,t]+epidemic.mat.Import.I[,t]))*(epidemic.mat.S[,t]/epidemic.mat.N))  - ((1/theta.1)*epidemic.mat.E[,t])
    epidemic.mat.I [,t+1]<-epidemic.mat.I [,t]  + ((1/theta.1)*epidemic.mat.E[,t]) - ((1/gamma.1)*epidemic.mat.I[,t])
    epidemic.mat.Q [,t+1]<-epidemic.mat.Q [,t]  + (q.prob.1)*((beta.1[[t]]%*%(epidemic.mat.I[,t]+epidemic.mat.Import.I[,t]))*(epidemic.mat.S[,t]/epidemic.mat.N))  - ((1/theta.1)*epidemic.mat.Q[,t])
    epidemic.mat.H [,t+1]<-epidemic.mat.H [,t]  + ((1/gamma.1)*epidemic.mat.I[,t]) + ((1/theta.1)*epidemic.mat.Q[,t])
  }
  newcase.1<-matrix(NA,ncol=ncol(epidemic.mat.S),nrow=num.metapop)
  newcase.1[,1]<-0
  for(j in 2:ncol(epidemic.mat.S)){newcase.1[,j]<-epidemic.mat.H[,j]-epidemic.mat.H[,j-1]}
  epidemic.mat.H.1<-epidemic.mat.H
  
  epidemic.mat.Import.I<-matrix(NA,ncol=time.duration,nrow=num.metapop)
  for(t in 1:time.duration){epidemic.mat.Import.I[,t]<-c(0,reported.imported.case[t+1]*gamma.2)}
  
  for(t in 1:(ncol(epidemic.mat.S)-1)){
    epidemic.mat.S [,t+1]<-epidemic.mat.S [,t]  - ((beta.2[[t]]%*%(epidemic.mat.I[,t]+epidemic.mat.Import.I[,t]))*(epidemic.mat.S[,t]/epidemic.mat.N))
    epidemic.mat.E [,t+1]<-epidemic.mat.E [,t]  + (1-q.prob.2)*((beta.2[[t]]%*%(epidemic.mat.I[,t]+epidemic.mat.Import.I[,t]))*(epidemic.mat.S[,t]/epidemic.mat.N))  - ((1/theta.2)*epidemic.mat.E[,t])
    epidemic.mat.I [,t+1]<-epidemic.mat.I [,t]  + ((1/theta.2)*epidemic.mat.E[,t]) - ((1/gamma.2)*epidemic.mat.I[,t])
    epidemic.mat.Q [,t+1]<-epidemic.mat.Q [,t]  + (q.prob.2)*((beta.2[[t]]%*%(epidemic.mat.I[,t]+epidemic.mat.Import.I[,t]))*(epidemic.mat.S[,t]/epidemic.mat.N))  - ((1/theta.2)*epidemic.mat.Q[,t])
    epidemic.mat.H [,t+1]<-epidemic.mat.H [,t]  + ((1/gamma.2)*epidemic.mat.I[,t]) + ((1/theta.2)*epidemic.mat.Q[,t])
  }
  newcase.2<-matrix(NA,ncol=ncol(epidemic.mat.S),nrow=num.metapop)
  newcase.2[,1]<-0
  for(j in 2:ncol(epidemic.mat.S)){newcase.2[,j]<-epidemic.mat.H[,j]-epidemic.mat.H[,j-1]}
  epidemic.mat.H.2<-epidemic.mat.H
  
  sce.3.results.mat[((x-1)*100)+y,1]<-gamma.2
  sce.3.results.mat[((x-1)*100)+y,2]<-q.prob.2
  sce.3.results.mat[((x-1)*100)+y,3]<-sum(epidemic.mat.H.2[,time.duration-6]-epidemic.mat.H.1[,time.duration-6])
  sce.3.results.mat[((x-1)*100)+y,4]<-sum(epidemic.mat.H.2[1,time.duration-6]-epidemic.mat.H.1[1,time.duration-6])
  sce.3.results.mat[((x-1)*100)+y,5]<-sum(epidemic.mat.H.2[2,time.duration-6]-epidemic.mat.H.1[2,time.duration-6])
}}


head(sce.3.results.mat)

library(directlabels)

sce.3.results.mat<-as.data.frame(sce.3.results.mat)
## contour plots
a<-ggplot(sce.3.results.mat, aes(x=gamma, y=qprob, z=changeincase_all))+
  stat_contour(geom='polygon',colour = "red",aes(fill=..level..))+
  geom_tile(aes(fill=changeincase_all)) +
  stat_contour(bins=10)+
  xlab("Time gap from onset to isolation")+
  ylab("Quarantine probability")+
  guides(fill=guide_colorbar(title='Excess Case')) 
b <-a+ geom_point(data=temp,aes(x=gamma,y=qprob),shape=3,size=6,color='red',stroke=3)
b
direct.label(a,"bottom.pieces")

p <- ggplot(sce.3.results.mat, aes(x=gamma, y=qprob, z=changeincase_all))+
  stat_contour(aes(colour = ..level..),size=2) +
  guides(fill=guide_colorbar(title='Excess Case')) +
  geom_point(data=temp,aes(x=gamma,y=qprob),shape=3,size=6,color='red',stroke=3)
direct.label(p,list("bottom.pieces",cex=1.5))

p <- ggplot(sce.3.results.mat, aes(x=gamma, y=qprob, z=changeincase_19))+
  stat_contour(aes(colour = ..level..),size=2) +
  guides(fill=guide_colorbar(title='Excess Case')) +
  geom_point(data=temp,aes(x=gamma,y=qprob),shape=3,size=6,color='red',stroke=3)
direct.label(p,list("bottom.pieces",cex=2))

p <- ggplot(sce.3.results.mat, aes(x=gamma, y=qprob, z=changeincase_20))+
  stat_contour(aes(colour = ..level..),size=2) +
  guides(fill=guide_colorbar(title='Excess Case')) +
  geom_point(data=temp,aes(x=gamma,y=qprob),shape=3,size=6,color='red',stroke=3)
direct.label(p,list("bottom.pieces",cex=1.8))


